﻿# Button — Hover and Behavior

> [English](hover-e-comportamento.md) | [Português do Brasil](hover-e-comportamento.pt-BR.md)

## Responsibility split

`TRickUIBuilderButtonHoverState` stores live configuration. `TRickUIBuilderButtonHoverBehavior`, a `TComponent`, executes `MouseEnter/MouseLeave` and keeps a strong reference to the state interface.

## Public state

`IRickUIBuilderButtonHoverState` exposes setters/getters for `Button`, `FillColor`, `HoverFillColor`, `OnEnter`, and `OnLeave`, plus `Build(AOwner)`. The decision about whether an explicit hover color was configured is internal to `TRickUIBuilderButtonHoverState`; `HasHoverFillColor` is not part of the public interface.

## MouseEnter

When the internal hover-color flag is set, Behavior applies the current `HoverFillColor` to `FButton`, then reads and invokes the current `OnEnter` handler.

## MouseLeave

When a hover color exists, Behavior restores the current `FillColor`, then reads and invokes the current `OnLeave` handler.

## Post-Build mutability

Behavior reads state on every event. Later changes to `FillColor`, `HoverFillColor`, `OnEnter`, and `OnLeave` therefore affect subsequent events without rebuilding. Setters do not repaint immediately: colors are consumed by the next corresponding event.

`Button(AValue)` is different: Behavior stores the `TRectangle` received by `Configure`. Changing `HoverState.Button` after `Build` does not retarget that Behavior.

## Builder

`HoverFillColor` and `OnHover` configure the same state used by Behavior. Even without an explicit hover color, the state is created and `OnHover` callbacks can run; color switching only happens when an explicit hover color was configured.

## Direct HoverState usage prerequisite

When `TRickUIBuilderButtonHoverState` is used directly, call `Button(AValue)` with a valid `TRectangle` before `Build(AOwner)`. The current `Build` implementation assigns `OnMouseEnter` and `OnMouseLeave` through the stored `FButton` without a nil guard. The Fluent Button Builder satisfies this prerequisite before building the hover state.

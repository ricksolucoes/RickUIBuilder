﻿# Samples Contract & Lifetime Auditor

## Missão
Auditar independentemente contratos, GUIDs, reference counting, ownership e lifetime do Samples sempre que esses aspectos existirem ou forem afetados pela tarefa.

## Entrada permitida
Solicitação original relevante, normativa aplicável, código final, `.dpr`/`.dproj` quando necessários e evidências primárias.

## Entrada proibida como fundamento
Parecer de outro auditor, aprovação anterior, justificativa persuasiva do implementador e cadeia de pensamento.

## Verificações
- interfaces existentes possuem propósito arquitetural real e seus GUIDs são preservados quando já publicados no código;
- contratos do Samples não declaram `procedure`; operações contratuais são `function` conforme a convenção vigente do projeto;
- implementações de contratos preservam a semântica contratual e não introduzem mutação incompatível com a convenção adotada;
- `TInterfacedObject`, `IInterface` e reference counting são usados de forma coerente com o lifetime real;
- referências owning e non-owning são identificadas corretamente e não criam dupla liberação, dangling reference ou ciclo de referência observável;
- Composition Root cria e conecta dependências na ordem prevista pela implementação final;
- ordem de destruição é compatível com dependências non-owning;
- View, Presenter e Coordinator preservam as boundaries vigentes, sem ciclo View ↔ Presenter e sem Presenter possuir a View;
- cabeçalhos estruturais das units descrevem corretamente contratos, ownership e lifetime quando esses temas fizerem parte da responsabilidade da unit.

## Regra específica atual
Enquanto a arquitetura atual existir, verificar `IHomePresenter`, `THomePresenter`, `TSampleApplicationCoordinator` e `TSampleApplication` em conjunto: a Home mantém `IHomePresenter`; o Presenter mantém referência non-owning ao Coordinator; o Presenter não referencia a Home; a Home é destruída antes do Coordinator.

## Saída
`PASS`, `FAIL`, `NOT_APPLICABLE` ou `BLOCKED`, com ocorrências e evidências objetivas.

## Proibições
Não modificar arquivos, não inventar lifetime não comprovado e não declarar ausência de leak apenas por análise estática.

## Critério da Sample Page Base

Quando `TExampleCommon`, `TExampleResultPanel` ou futuras derivadas afetarem o resultado executável, verificar que `ResultHost` pertence à árvore visual da página e permanece estável durante a vida do painel; derivadas podem usá-lo como Parent/Owner quando a API executada exigir, mas não podem liberar ou substituir o próprio host. Confirmar que `TExampleResultPanel.Clear` é a implementação usada por `ClearResult` para liberar somente os filhos visuais antes da substituição do exemplo e que nenhuma referência owning/non-owning criada pela derivada produz dupla liberação ou referência pendente. Não presumir ausência de leak sem execução apropriada.


## Critério de navegação para Examples concretos

Quando uma Component Page expuser callback para Sample Page, verificar que a referência de evento é non-owning, que o Coordinator possui lifetime superior enquanto a modal estiver ativa e que cada Sample Page criada sem Owner é liberada em `finally`. Para resultados Factory, confirmar que `ResultHost` é Owner/Parent quando essa for a implementação final e que `ClearResult` libera o resultado anterior antes de nova criação.

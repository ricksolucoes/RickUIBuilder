﻿{******************************************************************************}
{                                                                              }
{  RickUIBuilder.Samples.App.Coordinator                                       }
{                                                                              }
{ Esta unit coordena a abertura, integração e lifetime das Component Pages e   }
{ Sample Pages concretas, incluindo ComboBox Factory/Fluent e Edit Fluent como }
{ destinos reais.                                                               }
{                                                                              }
{  Finalidade                                                                  }
{  ----------                                                                  }
{  Coordenar o fluxo global e o lifetime das páginas modais do Samples.        }
{                                                                              }
{  Funcionalidade                                                              }
{  --------------                                                              }
{  Encerra a aplicação, resolve a Component Page concreta e conecta somente    }
{  intenções com Sample Pages reais de Text / Label, Button, Badge, Divider,    }
{  ComboBox e Edit, respeitando as abordagens concretamente implementadas.       }
{                                                                              }
{  Dependências do projeto                                                     }
{  -----------------------                                                     }
{  - RickUIBuilder.Samples.App.Types                                           }
{      Identifica o componente solicitado na navegação.                        }
{  - RickUIBuilder.Samples.Component.Common                                    }
{      Fornece TComponentCommon e a metaclasse das Component Pages.            }
{  - RickUIBuilder.Samples.Component.*                                         }
{      Fornecem as seis Component Pages concretas.                             }
{  - RickUIBuilder.Samples.Example.TextLabel.Factory/Fluent                    }
{      Fornecem os destinos concretos de Text / Label.                         }
{  - RickUIBuilder.Samples.Example.Button.Factory/Fluent                       }
{      Fornecem os destinos concretos de Button.                               }
{  - RickUIBuilder.Samples.Example.Badge.Factory/Fluent                        }
{      Fornecem os destinos concretos de Badge.                                }
{  - RickUIBuilder.Samples.Example.Divider.Factory/Fluent                      }
{      Fornecem os destinos concretos de Divider.                              }
{  - RickUIBuilder.Samples.Example.ComboBox.Factory/Fluent                     }
{      Fornecem os destinos concretos de ComboBox.                             }
{  - RickUIBuilder.Samples.Example.Edit.Fluent                                 }
{      Fornece o destino concreto Fluent Builder de Edit.                      }
{                                                                              }
{  Fluxo / colaboração                                                         }
{  -------------------                                                         }
{  - Home/Presenter solicitam OpenComponent.                                   }
{  - OpenComponent cria a Component Page, conecta intenções disponíveis e      }
{    aguarda ShowModal.                                                        }
{  - Os callbacks abrem somente Sample Pages concretas existentes.             }
{  - Ao fechar a Sample Page, a Component Page correspondente volta a ativa.   }
{                                                                              }
{  Ownership / lifetime                                                        }
{  --------------------                                                        }
{  - Component Pages e Sample Pages são criadas sem Owner.                     }
{  - O Coordinator libera cada instância em bloco finally após ShowModal.      }
{  - Os callbacks armazenados pelas Component Pages são non-owning; o          }
{    Coordinator possui lifetime superior durante toda a navegação.            }
{                                                                              }
{  Restrições e responsabilidades                                              }
{  -----------------------------                                               }
{  - Não contém controles, snippets ou regras visuais das pages.               }
{  - Só conhece destinos que realmente existem no código final.                }
{  - Não executa Factory/Fluent; somente coordena a navegação.                 }
{                                                                              }
{  Manutenção                                                                  }
{  ----------                                                                  }
{  Atualizar este cabeçalho quando destinos, callbacks, ownership ou fluxo     }
{  modal mudarem.                                                              }
{                                                                              }
{******************************************************************************}

unit RickUIBuilder.Samples.App.Coordinator;

interface

uses
  RickUIBuilder.Samples.App.Types;

type
  /// <summary>Coordena o fluxo global atualmente necessário ao Samples.</summary>
  TSampleApplicationCoordinator = class
  strict private
    procedure ConfigureComponentPage(const AComponent: TSampleComponent;
      const APage: TObject);
    procedure ConfigureDualApproachComponentPage(
      const AComponent: TSampleComponent; const APage: TObject);
    procedure ConfigureTextLabelPage(const APage: TObject);
    procedure ConfigureButtonPage(const APage: TObject);
    procedure ConfigureBadgePage(const APage: TObject);
    procedure ConfigureDividerPage(const APage: TObject);
    procedure ConfigureComboBoxPage(const APage: TObject);
    procedure ConfigureEditPage(const APage: TObject);
    procedure TextLabelFactoryRequested(ASender: TObject);
    procedure TextLabelFluentRequested(ASender: TObject);
    procedure ButtonFactoryRequested(ASender: TObject);
    procedure ButtonFluentRequested(ASender: TObject);
    procedure BadgeFactoryRequested(ASender: TObject);
    procedure BadgeFluentRequested(ASender: TObject);
    procedure DividerFactoryRequested(ASender: TObject);
    procedure DividerFluentRequested(ASender: TObject);
    procedure ComboBoxFactoryRequested(ASender: TObject);
    procedure ComboBoxFluentRequested(ASender: TObject);
    procedure EditFluentRequested(ASender: TObject);
    procedure OpenTextLabelFactory;
    procedure OpenTextLabelFluent;
    procedure OpenButtonFactory;
    procedure OpenButtonFluent;
    procedure OpenBadgeFactory;
    procedure OpenBadgeFluent;
    procedure OpenDividerFactory;
    procedure OpenDividerFluent;
    procedure OpenComboBoxFactory;
    procedure OpenComboBoxFluent;
    procedure OpenEditFluent;
  public
    /// <summary>Encerra o loop principal da aplicação.</summary>
    function Close: TSampleApplicationCoordinator;
    /// <summary>Abre modalmente a página concreta do componente solicitado.</summary>
    function OpenComponent(const AComponent: TSampleComponent): TSampleApplicationCoordinator;
  end;

implementation

uses
  FMX.Forms,
  RickUIBuilder.Samples.Component.Edit,
  RickUIBuilder.Samples.Component.Badge,
  RickUIBuilder.Samples.Component.Common,
  RickUIBuilder.Samples.Component.Button,
  RickUIBuilder.Samples.Component.Divider,
  RickUIBuilder.Samples.Component.ComboBox,
  RickUIBuilder.Samples.Component.TextLabel,
  RickUIBuilder.Samples.Example.Badge.Factory,
  RickUIBuilder.Samples.Example.Badge.Fluent,
  RickUIBuilder.Samples.Example.Button.Factory,
  RickUIBuilder.Samples.Example.Button.Fluent,
  RickUIBuilder.Samples.Example.Divider.Factory,
  RickUIBuilder.Samples.Example.Divider.Fluent,
  RickUIBuilder.Samples.Example.ComboBox.Factory,
  RickUIBuilder.Samples.Example.ComboBox.Fluent,
  RickUIBuilder.Samples.Example.Edit.Fluent,
  RickUIBuilder.Samples.Example.TextLabel.Factory,
  RickUIBuilder.Samples.Example.TextLabel.Fluent;

const
  _COMPONENT_PAGE_CLASSES_: array[TSampleComponent] of TComponentPageClass = (
    TComponentTextLabel,
    TComponentButton,
    TComponentBadge,
    TComponentDivider,
    TComponentComboBox,
    TComponentEdit);

function TSampleApplicationCoordinator.Close: TSampleApplicationCoordinator;
begin
  Application.Terminate;
  Result := Self;
end;

function TSampleApplicationCoordinator.OpenComponent(
  const AComponent: TSampleComponent): TSampleApplicationCoordinator;
var
  LPage: TComponentCommon;
begin
  LPage := _COMPONENT_PAGE_CLASSES_[AComponent].Create(nil);
  try
    ConfigureComponentPage(AComponent, LPage);
    LPage.ShowModal;
  finally
    LPage.Free;
  end;
  Result := Self;
end;

procedure TSampleApplicationCoordinator.ConfigureComponentPage(
  const AComponent: TSampleComponent; const APage: TObject);
begin
  if AComponent = TSampleComponent.Edit then
    ConfigureEditPage(APage)
  else
    ConfigureDualApproachComponentPage(AComponent, APage);
end;

procedure TSampleApplicationCoordinator.ConfigureDualApproachComponentPage(
  const AComponent: TSampleComponent; const APage: TObject);
begin
  case AComponent of
    TSampleComponent.TextLabel: ConfigureTextLabelPage(APage);
    TSampleComponent.Button: ConfigureButtonPage(APage);
    TSampleComponent.Badge: ConfigureBadgePage(APage);
    TSampleComponent.Divider: ConfigureDividerPage(APage);
    TSampleComponent.ComboBox: ConfigureComboBoxPage(APage);
  end;
end;

procedure TSampleApplicationCoordinator.ConfigureTextLabelPage(
  const APage: TObject);
begin
  TComponentTextLabel(APage).OnFactoryExamples := TextLabelFactoryRequested;
  TComponentTextLabel(APage).OnFluentExamples := TextLabelFluentRequested;
end;

procedure TSampleApplicationCoordinator.ConfigureButtonPage(
  const APage: TObject);
begin
  TComponentButton(APage).OnFactoryExamples := ButtonFactoryRequested;
  TComponentButton(APage).OnFluentExamples := ButtonFluentRequested;
end;

procedure TSampleApplicationCoordinator.ConfigureBadgePage(
  const APage: TObject);
begin
  TComponentBadge(APage).OnFactoryExamples := BadgeFactoryRequested;
  TComponentBadge(APage).OnFluentExamples := BadgeFluentRequested;
end;

procedure TSampleApplicationCoordinator.ConfigureDividerPage(
  const APage: TObject);
begin
  TComponentDivider(APage).OnFactoryExamples := DividerFactoryRequested;
  TComponentDivider(APage).OnFluentExamples := DividerFluentRequested;
end;

procedure TSampleApplicationCoordinator.ConfigureComboBoxPage(
  const APage: TObject);
begin
  TComponentComboBox(APage).OnFactoryExamples := ComboBoxFactoryRequested;
  TComponentComboBox(APage).OnFluentExamples := ComboBoxFluentRequested;
end;


procedure TSampleApplicationCoordinator.ConfigureEditPage(
  const APage: TObject);
begin
  TComponentEdit(APage).OnFluentExamples := EditFluentRequested;
end;

procedure TSampleApplicationCoordinator.TextLabelFactoryRequested(
  ASender: TObject);
begin
  OpenTextLabelFactory;
end;

procedure TSampleApplicationCoordinator.TextLabelFluentRequested(
  ASender: TObject);
begin
  OpenTextLabelFluent;
end;

procedure TSampleApplicationCoordinator.ButtonFactoryRequested(
  ASender: TObject);
begin
  OpenButtonFactory;
end;

procedure TSampleApplicationCoordinator.ButtonFluentRequested(
  ASender: TObject);
begin
  OpenButtonFluent;
end;

procedure TSampleApplicationCoordinator.BadgeFactoryRequested(
  ASender: TObject);
begin
  OpenBadgeFactory;
end;

procedure TSampleApplicationCoordinator.BadgeFluentRequested(
  ASender: TObject);
begin
  OpenBadgeFluent;
end;

procedure TSampleApplicationCoordinator.DividerFactoryRequested(
  ASender: TObject);
begin
  OpenDividerFactory;
end;

procedure TSampleApplicationCoordinator.DividerFluentRequested(
  ASender: TObject);
begin
  OpenDividerFluent;
end;

procedure TSampleApplicationCoordinator.ComboBoxFactoryRequested(
  ASender: TObject);
begin
  OpenComboBoxFactory;
end;

procedure TSampleApplicationCoordinator.ComboBoxFluentRequested(
  ASender: TObject);
begin
  OpenComboBoxFluent;
end;


procedure TSampleApplicationCoordinator.EditFluentRequested(ASender: TObject);
begin
  OpenEditFluent;
end;

procedure TSampleApplicationCoordinator.OpenTextLabelFactory;
var
  LPage: TExampleTextLabelFactory;
begin
  LPage := TExampleTextLabelFactory.Create(nil);
  try
    LPage.ShowModal;
  finally
    LPage.Free;
  end;
end;

procedure TSampleApplicationCoordinator.OpenTextLabelFluent;
var
  LPage: TExampleTextLabelFluent;
begin
  LPage := TExampleTextLabelFluent.Create(nil);
  try
    LPage.ShowModal;
  finally
    LPage.Free;
  end;
end;

procedure TSampleApplicationCoordinator.OpenButtonFactory;
var
  LPage: TExampleButtonFactory;
begin
  LPage := TExampleButtonFactory.Create(nil);
  try
    LPage.ShowModal;
  finally
    LPage.Free;
  end;
end;

procedure TSampleApplicationCoordinator.OpenButtonFluent;
var
  LPage: TExampleButtonFluent;
begin
  LPage := TExampleButtonFluent.Create(nil);
  try
    LPage.ShowModal;
  finally
    LPage.Free;
  end;
end;

procedure TSampleApplicationCoordinator.OpenBadgeFactory;
var
  LPage: TExampleBadgeFactory;
begin
  LPage := TExampleBadgeFactory.Create(nil);
  try
    LPage.ShowModal;
  finally
    LPage.Free;
  end;
end;

procedure TSampleApplicationCoordinator.OpenBadgeFluent;
var
  LPage: TExampleBadgeFluent;
begin
  LPage := TExampleBadgeFluent.Create(nil);
  try
    LPage.ShowModal;
  finally
    LPage.Free;
  end;
end;

procedure TSampleApplicationCoordinator.OpenDividerFactory;
var
  LPage: TExampleDividerFactory;
begin
  LPage := TExampleDividerFactory.Create(nil);
  try
    LPage.ShowModal;
  finally
    LPage.Free;
  end;
end;

procedure TSampleApplicationCoordinator.OpenDividerFluent;
var
  LPage: TExampleDividerFluent;
begin
  LPage := TExampleDividerFluent.Create(nil);
  try
    LPage.ShowModal;
  finally
    LPage.Free;
  end;
end;

procedure TSampleApplicationCoordinator.OpenComboBoxFactory;
var
  LPage: TExampleComboBoxFactory;
begin
  LPage := TExampleComboBoxFactory.Create(nil);
  try
    LPage.ShowModal;
  finally
    LPage.Free;
  end;
end;

procedure TSampleApplicationCoordinator.OpenComboBoxFluent;
var
  LPage: TExampleComboBoxFluent;
begin
  LPage := TExampleComboBoxFluent.Create(nil);
  try
    LPage.ShowModal;
  finally
    LPage.Free;
  end;
end;

procedure TSampleApplicationCoordinator.OpenEditFluent;
var
  LPage: TExampleEditFluent;
begin
  LPage := TExampleEditFluent.Create(nil);
  try
    LPage.ShowModal;
  finally
    LPage.Free;
  end;
end;

end.

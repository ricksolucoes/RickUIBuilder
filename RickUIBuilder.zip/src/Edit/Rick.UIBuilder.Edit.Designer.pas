﻿unit Rick.UIBuilder.Edit.Designer;

interface

uses
  System.UITypes,
  FMX.Edit,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces,
  Rick.UIBuilder.Edit.Types;

type
  TRickUIBuilderEditDesigner = class(TInterfacedObject, IRickUIBuilderEditDesigner)
  strict private
    [weak] FParent: IRickUIBuilderEdit;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
    FInput: IRickUIBuilderEditDesignerInput;
    FValidation: IRickUIBuilderEditDesignerValidation;
    FConfig: IRickUIBuilderEditDesignerConfig;
  protected
    constructor Create(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditDesigner; static;
    function Input: IRickUIBuilderEditDesignerInput;
    function Validation: IRickUIBuilderEditDesignerValidation;
    function Config: IRickUIBuilderEditDesignerConfig;
    function Clear: IRickUIBuilderEditDesigner;
    function Control: TEdit;
    function ToBack: IRickUIBuilderEdit;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction,
  Rick.UIBuilder.Edit.Designer.Input,
  Rick.UIBuilder.Edit.Designer.Validation,
  Rick.UIBuilder.Edit.Designer.Config;

constructor TRickUIBuilderEditDesigner.Create(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditDesigner.New(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditDesigner;
begin
  Result := TRickUIBuilderEditDesigner.Create(AParent, AContext);
end;

function TRickUIBuilderEditDesigner.Input: IRickUIBuilderEditDesignerInput;
begin
  if not Assigned(FInput) then
    FInput := TRickUIBuilderEditDesignerInput.New(Self, FContext);
  Result := FInput;
end;

function TRickUIBuilderEditDesigner.Validation: IRickUIBuilderEditDesignerValidation;
begin
  if not Assigned(FValidation) then
    FValidation := TRickUIBuilderEditDesignerValidation.New(Self, FContext);
  Result := FValidation;
end;

function TRickUIBuilderEditDesigner.Config: IRickUIBuilderEditDesignerConfig;
begin
  if not Assigned(FConfig) then
    FConfig := TRickUIBuilderEditDesignerConfig.New(Self, FContext);
  Result := FConfig;
end;

function TRickUIBuilderEditDesigner.Clear: IRickUIBuilderEditDesigner;
var
  LInteraction: TRickUIBuilderEditInteraction;
begin
  FContext.Settings.Designer.Text := EmptyStr;
  FContext.Settings.Designer.HasInvalid := False;
  FContext.Settings.Designer.Invalid := False;
  FContext.Settings.Designer.InvalidMessage := EmptyStr;
  LInteraction := nil;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    LInteraction := TRickUIBuilderEditInteraction(FContext.Interaction);
  if Assigned(LInteraction) then
    LInteraction.Clear;
  Result := Self;
end;

function TRickUIBuilderEditDesigner.Control: TEdit;
begin
  Result := FContext.EditControl;
end;

function TRickUIBuilderEditDesigner.ToBack: IRickUIBuilderEdit;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

﻿unit Rick.UIBuilder.Edit.Designer.Input.Text;

interface

uses
  System.UITypes,
  FMX.Edit,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces,
  Rick.UIBuilder.Edit.Types;

type
  TRickUIBuilderEditDesignerInputText = class(TInterfacedObject, IRickUIBuilderEditDesignerInputText)
  strict private
    [weak] FParent: IRickUIBuilderEditDesignerInput;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
    FColor: IRickUIBuilderEditDesignerInputTextColor;
  protected
    constructor Create(const AParent: IRickUIBuilderEditDesignerInput; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditDesignerInput; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditDesignerInputText; static;
    function Value(const AValue: string): IRickUIBuilderEditDesignerInputText; overload;
    function Value: string; overload;
    function Color: IRickUIBuilderEditDesignerInputTextColor;
    function Size(AValue: Single): IRickUIBuilderEditDesignerInputText;
    function ToBack: IRickUIBuilderEditDesignerInput;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction,
  Rick.UIBuilder.Edit.Designer.Input.Text.Color;

constructor TRickUIBuilderEditDesignerInputText.Create(const AParent: IRickUIBuilderEditDesignerInput; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditDesignerInputText.New(const AParent: IRickUIBuilderEditDesignerInput; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditDesignerInputText;
begin
  Result := TRickUIBuilderEditDesignerInputText.Create(AParent, AContext);
end;

function TRickUIBuilderEditDesignerInputText.Value(const AValue: string): IRickUIBuilderEditDesignerInputText;
var
  LInteraction: TRickUIBuilderEditInteraction;
begin
  FContext.Settings.Designer.Text := AValue;
  LInteraction := nil;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    LInteraction := TRickUIBuilderEditInteraction(FContext.Interaction);
  if Assigned(LInteraction) then
    LInteraction.SetText(AValue);
  Result := Self;
end;

function TRickUIBuilderEditDesignerInputText.Value: string;
begin
  if Assigned(FContext.EditControl) then
    Exit(FContext.EditControl.Text);
  Result := FContext.Settings.Designer.Text;
end;

function TRickUIBuilderEditDesignerInputText.Color: IRickUIBuilderEditDesignerInputTextColor;
begin
  if not Assigned(FColor) then
    FColor := TRickUIBuilderEditDesignerInputTextColor.New(Self, FContext);
  Result := FColor;
end;

function TRickUIBuilderEditDesignerInputText.Size(AValue: Single): IRickUIBuilderEditDesignerInputText;
begin
  FContext.Settings.Designer.FontSize := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerInputText.ToBack: IRickUIBuilderEditDesignerInput;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

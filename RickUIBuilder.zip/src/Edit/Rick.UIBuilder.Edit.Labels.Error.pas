﻿unit Rick.UIBuilder.Edit.Labels.Error;

interface

uses
  System.UITypes,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces;

type
  TRickUIBuilderEditLabelError = class(TInterfacedObject, IRickUIBuilderEditLabelError)
  strict private
    [weak] FParent: IRickUIBuilderEditLabel;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
    FText: IRickUIBuilderEditLabelErrorText;
  protected
    constructor Create(const AParent: IRickUIBuilderEditLabel; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditLabel; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLabelError; static;
    function Text: IRickUIBuilderEditLabelErrorText;
    function ToBack: IRickUIBuilderEditLabel;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Labels.Error.Text;

constructor TRickUIBuilderEditLabelError.Create(const AParent: IRickUIBuilderEditLabel; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditLabelError.New(const AParent: IRickUIBuilderEditLabel; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLabelError;
begin
  Result := TRickUIBuilderEditLabelError.Create(AParent, AContext);
end;

function TRickUIBuilderEditLabelError.Text: IRickUIBuilderEditLabelErrorText;
begin
  if not Assigned(FText) then
    FText := TRickUIBuilderEditLabelErrorText.New(Self, FContext);
  Result := FText;
end;

function TRickUIBuilderEditLabelError.ToBack: IRickUIBuilderEditLabel;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

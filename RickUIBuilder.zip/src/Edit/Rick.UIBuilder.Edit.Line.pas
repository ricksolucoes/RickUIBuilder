﻿unit Rick.UIBuilder.Edit.Line;

interface

uses
  System.UITypes,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces;

type
  TRickUIBuilderEditLine = class(TInterfacedObject, IRickUIBuilderEditLine)
  strict private
    [weak] FParent: IRickUIBuilderEdit;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
    FColor: IRickUIBuilderEditLineColor;
  protected
    constructor Create(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLine; static;
    function Thickness(AValue: Single): IRickUIBuilderEditLine;
    function Color: IRickUIBuilderEditLineColor;
    function ToBack: IRickUIBuilderEdit;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction,
  Rick.UIBuilder.Edit.Line.Color;

constructor TRickUIBuilderEditLine.Create(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditLine.New(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLine;
begin
  Result := TRickUIBuilderEditLine.Create(AParent, AContext);
end;

function TRickUIBuilderEditLine.Thickness(AValue: Single): IRickUIBuilderEditLine;
begin
  FContext.Settings.Line.Thickness := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditLine.Color: IRickUIBuilderEditLineColor;
begin
  if not Assigned(FColor) then
    FColor := TRickUIBuilderEditLineColor.New(Self, FContext);
  Result := FColor;
end;

function TRickUIBuilderEditLine.ToBack: IRickUIBuilderEdit;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

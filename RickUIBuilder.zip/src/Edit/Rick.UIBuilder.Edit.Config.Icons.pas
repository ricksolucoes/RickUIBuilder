﻿unit Rick.UIBuilder.Edit.Config.Icons;

interface

uses
  System.UITypes,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces,
  Rick.UIBuilder.Edit.Types;

type
  TRickUIBuilderEditConfigIcons = class(TInterfacedObject, IRickUIBuilderEditConfigIcons)
  strict private
    [weak] FParent: IRickUIBuilderEditConfig;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
    FColors: IRickUIBuilderEditConfigIconColors;
    FPaths: IRickUIBuilderEditConfigIconPaths;
  protected
    constructor Create(const AParent: IRickUIBuilderEditConfig; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditConfig; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditConfigIcons; static;
    function Size(AValue: Single): IRickUIBuilderEditConfigIcons;
    function Colors: IRickUIBuilderEditConfigIconColors;
    function Paths: IRickUIBuilderEditConfigIconPaths;
    function ToBack: IRickUIBuilderEditConfig;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction,
  Rick.UIBuilder.Edit.Config.Icons.Colors,
  Rick.UIBuilder.Edit.Config.Icons.Paths;

constructor TRickUIBuilderEditConfigIcons.Create(const AParent: IRickUIBuilderEditConfig; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditConfigIcons.New(const AParent: IRickUIBuilderEditConfig; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditConfigIcons;
begin
  Result := TRickUIBuilderEditConfigIcons.Create(AParent, AContext);
end;

function TRickUIBuilderEditConfigIcons.Size(AValue: Single): IRickUIBuilderEditConfigIcons;
begin
  FContext.Settings.Config.Icons.Size := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditConfigIcons.Colors: IRickUIBuilderEditConfigIconColors;
begin
  if not Assigned(FColors) then
    FColors := TRickUIBuilderEditConfigIconColors.New(Self, FContext);
  Result := FColors;
end;

function TRickUIBuilderEditConfigIcons.Paths: IRickUIBuilderEditConfigIconPaths;
begin
  if not Assigned(FPaths) then
    FPaths := TRickUIBuilderEditConfigIconPaths.New(Self, FContext);
  Result := FPaths;
end;

function TRickUIBuilderEditConfigIcons.ToBack: IRickUIBuilderEditConfig;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

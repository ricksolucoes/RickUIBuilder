﻿unit Rick.UIBuilder.Edit.Rectangle.Border;

interface

uses
  System.UITypes,
  FMX.Objects,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces;

type
  TRickUIBuilderEditRetangleBorder = class(TInterfacedObject, IRickUIBuilderEditRetangleBorder)
  strict private
    [weak] FParent: IRickUIBuilderEditRetangle;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
  protected
    constructor Create(const AParent: IRickUIBuilderEditRetangle; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditRetangle; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditRetangleBorder; static;
    function Thickness(AValue: Single): IRickUIBuilderEditRetangleBorder;
    function Normal(AValue: TAlphaColor): IRickUIBuilderEditRetangleBorder;
    function Focus(AValue: TAlphaColor): IRickUIBuilderEditRetangleBorder;
    function Invalid(AValue: TAlphaColor): IRickUIBuilderEditRetangleBorder;
    function ReadOnly(AValue: TAlphaColor): IRickUIBuilderEditRetangleBorder;
    function ToBack: IRickUIBuilderEditRetangle;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction;

constructor TRickUIBuilderEditRetangleBorder.Create(const AParent: IRickUIBuilderEditRetangle; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditRetangleBorder.New(const AParent: IRickUIBuilderEditRetangle; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditRetangleBorder;
begin
  Result := TRickUIBuilderEditRetangleBorder.Create(AParent, AContext);
end;

function TRickUIBuilderEditRetangleBorder.Thickness(AValue: Single): IRickUIBuilderEditRetangleBorder;
begin
  FContext.Settings.Rectangle.BorderThickness := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditRetangleBorder.Normal(AValue: TAlphaColor): IRickUIBuilderEditRetangleBorder;
begin
  FContext.Settings.Rectangle.BorderColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditRetangleBorder.Focus(AValue: TAlphaColor): IRickUIBuilderEditRetangleBorder;
begin
  FContext.Settings.Rectangle.FocusBorderColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditRetangleBorder.Invalid(AValue: TAlphaColor): IRickUIBuilderEditRetangleBorder;
begin
  FContext.Settings.Rectangle.InvalidBorderColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditRetangleBorder.ReadOnly(AValue: TAlphaColor): IRickUIBuilderEditRetangleBorder;
begin
  FContext.Settings.Rectangle.ReadOnlyBorderColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditRetangleBorder.ToBack: IRickUIBuilderEditRetangle;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

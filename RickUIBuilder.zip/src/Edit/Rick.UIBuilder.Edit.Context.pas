﻿unit Rick.UIBuilder.Edit.Context;

interface

uses
  System.Classes,
  FMX.Edit,
  FMX.Layouts,
  FMX.Objects,
  FMX.StdCtrls,
  Rick.UIBuilder.Edit.Types;

type
  TRickUIBuilderEditContext = class(TInterfacedObject)
  strict private
    FContainer: TRectangle;
    FEditBackground: TRectangle;
    FEditControl: TEdit;
    FMainLabel: TLabel;
    FCounterLabel: TLabel;
    FErrorLabel: TLabel;
    FLineControl: TRectangle;
    FAlertPath: TPath;
    FClearArea: TLayout;
    FClearPath: TPath;
    FPasswordArea: TLayout;
    FPasswordPath: TPath;
    FRequirementPath: TPath;
    FInteraction: TObject;
  public
    Settings: TRickUIBuilderEditSettings;
    constructor Create;
    procedure AttachCore(AContainer, AEditBackground: TRectangle; AEditControl: TEdit; ALineControl: TRectangle);
    procedure AttachLabels(AMainLabel, ACounterLabel, AErrorLabel: TLabel);
    procedure AttachActions(AAlertPath: TPath; AClearArea: TLayout; AClearPath: TPath; APasswordArea: TLayout; APasswordPath, ARequirementPath: TPath);
    procedure Detach(AContainer: TRectangle);
    function IsAttached: Boolean;
    property Container: TRectangle read FContainer;
    property EditBackground: TRectangle read FEditBackground;
    property EditControl: TEdit read FEditControl;
    property MainLabel: TLabel read FMainLabel;
    property CounterLabel: TLabel read FCounterLabel;
    property ErrorLabel: TLabel read FErrorLabel;
    property LineControl: TRectangle read FLineControl;
    property AlertPath: TPath read FAlertPath;
    property ClearArea: TLayout read FClearArea;
    property ClearPath: TPath read FClearPath;
    property PasswordArea: TLayout read FPasswordArea;
    property PasswordPath: TPath read FPasswordPath;
    property RequirementPath: TPath read FRequirementPath;
    property Interaction: TObject read FInteraction write FInteraction;
  end;

implementation

constructor TRickUIBuilderEditContext.Create;
begin
  inherited Create;
  Settings := TRickUIBuilderEditSettings.Default;
end;

procedure TRickUIBuilderEditContext.AttachCore(AContainer, AEditBackground: TRectangle; AEditControl: TEdit; ALineControl: TRectangle);
begin
  FContainer := AContainer;
  FEditBackground := AEditBackground;
  FEditControl := AEditControl;
  FLineControl := ALineControl;
end;

procedure TRickUIBuilderEditContext.AttachLabels(AMainLabel, ACounterLabel, AErrorLabel: TLabel);
begin
  FMainLabel := AMainLabel;
  FCounterLabel := ACounterLabel;
  FErrorLabel := AErrorLabel;
end;

procedure TRickUIBuilderEditContext.AttachActions(AAlertPath: TPath; AClearArea: TLayout; AClearPath: TPath; APasswordArea: TLayout; APasswordPath, ARequirementPath: TPath);
begin
  FAlertPath := AAlertPath;
  FClearArea := AClearArea;
  FClearPath := AClearPath;
  FPasswordArea := APasswordArea;
  FPasswordPath := APasswordPath;
  FRequirementPath := ARequirementPath;
end;

procedure TRickUIBuilderEditContext.Detach(AContainer: TRectangle);
begin
  if FContainer <> AContainer then
    Exit;
  FContainer := nil;
  FEditBackground := nil;
  FEditControl := nil;
  FMainLabel := nil;
  FCounterLabel := nil;
  FErrorLabel := nil;
  FLineControl := nil;
  FAlertPath := nil;
  FClearArea := nil;
  FClearPath := nil;
  FPasswordArea := nil;
  FPasswordPath := nil;
  FRequirementPath := nil;
  FInteraction := nil;
end;

function TRickUIBuilderEditContext.IsAttached: Boolean;
begin
  Result := Assigned(FContainer) and Assigned(FEditControl);
end;

end.

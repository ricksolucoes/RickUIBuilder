﻿unit Rick.UIBuilder.Edit.Designer.Input;

interface

uses
  System.UITypes,
  FMX.Edit,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces,
  Rick.UIBuilder.Edit.Types;

type
  TRickUIBuilderEditDesignerInput = class(TInterfacedObject, IRickUIBuilderEditDesignerInput)
  strict private
    [weak] FParent: IRickUIBuilderEditDesigner;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
    FText: IRickUIBuilderEditDesignerInputText;
    FNumber: IRickUIBuilderEditDesignerInputNumber;
    FConfig: IRickUIBuilderEditDesignerInputConfig;
  protected
    constructor Create(const AParent: IRickUIBuilderEditDesigner; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditDesigner; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditDesignerInput; static;
    function Text: IRickUIBuilderEditDesignerInputText;
    function Number: IRickUIBuilderEditDesignerInputNumber;
    function Config: IRickUIBuilderEditDesignerInputConfig;
    function ToBack: IRickUIBuilderEditDesigner;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Designer.Input.Text,
  Rick.UIBuilder.Edit.Designer.Input.Number,
  Rick.UIBuilder.Edit.Designer.Input.Config;

constructor TRickUIBuilderEditDesignerInput.Create(const AParent: IRickUIBuilderEditDesigner; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditDesignerInput.New(const AParent: IRickUIBuilderEditDesigner; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditDesignerInput;
begin
  Result := TRickUIBuilderEditDesignerInput.Create(AParent, AContext);
end;

function TRickUIBuilderEditDesignerInput.Text: IRickUIBuilderEditDesignerInputText;
begin
  if not Assigned(FText) then
    FText := TRickUIBuilderEditDesignerInputText.New(Self, FContext);
  Result := FText;
end;

function TRickUIBuilderEditDesignerInput.Number: IRickUIBuilderEditDesignerInputNumber;
begin
  if not Assigned(FNumber) then
    FNumber := TRickUIBuilderEditDesignerInputNumber.New(Self, FContext);
  Result := FNumber;
end;

function TRickUIBuilderEditDesignerInput.Config: IRickUIBuilderEditDesignerInputConfig;
begin
  if not Assigned(FConfig) then
    FConfig := TRickUIBuilderEditDesignerInputConfig.New(Self, FContext);
  Result := FConfig;
end;

function TRickUIBuilderEditDesignerInput.ToBack: IRickUIBuilderEditDesigner;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

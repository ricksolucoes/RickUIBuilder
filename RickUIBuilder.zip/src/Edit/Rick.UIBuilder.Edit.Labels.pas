﻿unit Rick.UIBuilder.Edit.Labels;

interface

uses
  System.UITypes,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces;

type
  TRickUIBuilderEditLabel = class(TInterfacedObject, IRickUIBuilderEditLabel)
  strict private
    [weak] FParent: IRickUIBuilderEdit;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
    FMain: IRickUIBuilderEditLabelMain;
    FCounter: IRickUIBuilderEditLabelCounter;
    FError: IRickUIBuilderEditLabelError;
  protected
    constructor Create(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLabel; static;
    function Main: IRickUIBuilderEditLabelMain;
    function Counter: IRickUIBuilderEditLabelCounter;
    function Error: IRickUIBuilderEditLabelError;
    function ToBack: IRickUIBuilderEdit;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Labels.Main,
  Rick.UIBuilder.Edit.Labels.Counter,
  Rick.UIBuilder.Edit.Labels.Error;

constructor TRickUIBuilderEditLabel.Create(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditLabel.New(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLabel;
begin
  Result := TRickUIBuilderEditLabel.Create(AParent, AContext);
end;

function TRickUIBuilderEditLabel.Main: IRickUIBuilderEditLabelMain;
begin
  if not Assigned(FMain) then
    FMain := TRickUIBuilderEditLabelMain.New(Self, FContext);
  Result := FMain;
end;

function TRickUIBuilderEditLabel.Counter: IRickUIBuilderEditLabelCounter;
begin
  if not Assigned(FCounter) then
    FCounter := TRickUIBuilderEditLabelCounter.New(Self, FContext);
  Result := FCounter;
end;

function TRickUIBuilderEditLabel.Error: IRickUIBuilderEditLabelError;
begin
  if not Assigned(FError) then
    FError := TRickUIBuilderEditLabelError.New(Self, FContext);
  Result := FError;
end;

function TRickUIBuilderEditLabel.ToBack: IRickUIBuilderEdit;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

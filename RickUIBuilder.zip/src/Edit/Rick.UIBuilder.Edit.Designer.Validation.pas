﻿unit Rick.UIBuilder.Edit.Designer.Validation;

interface

uses
  System.UITypes,
  FMX.Edit,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces,
  Rick.UIBuilder.Edit.Types;

type
  TRickUIBuilderEditDesignerValidation = class(TInterfacedObject, IRickUIBuilderEditDesignerValidation)
  strict private
    [weak] FParent: IRickUIBuilderEditDesigner;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
  protected
    constructor Create(const AParent: IRickUIBuilderEditDesigner; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditDesigner; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditDesignerValidation; static;
    function Required(AValue: Boolean): IRickUIBuilderEditDesignerValidation; overload;
    function Required: IRickUIBuilderEditDesignerValidation; overload;
    function RequirementIndicator(AValue: Boolean): IRickUIBuilderEditDesignerValidation; overload;
    function RequirementIndicator: IRickUIBuilderEditDesignerValidation; overload;
    function Feedback(AValue: TRickUIBuilderEditInvalidFeedback): IRickUIBuilderEditDesignerValidation;
    function DefaultMessage(const AValue: string): IRickUIBuilderEditDesignerValidation;
    function Invalid(AValue: Boolean): IRickUIBuilderEditDesignerValidation; overload;
    function Invalid(const AMessage: string): IRickUIBuilderEditDesignerValidation; overload;
    function Invalid(AValue: Boolean; const AMessage: string): IRickUIBuilderEditDesignerValidation; overload;
    function HasInvalid: Boolean;
    function InvalidValue: Boolean;
    function InvalidMessage: string;
    function RequirementMet(AValue: Boolean): IRickUIBuilderEditDesignerValidation; overload;
    function RequirementMet: IRickUIBuilderEditDesignerValidation; overload;
    function HasRequirementMet: Boolean;
    function RequirementMetValue: Boolean;
    function ToBack: IRickUIBuilderEditDesigner;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction;

constructor TRickUIBuilderEditDesignerValidation.Create(const AParent: IRickUIBuilderEditDesigner; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditDesignerValidation.New(const AParent: IRickUIBuilderEditDesigner; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditDesignerValidation;
begin
  Result := TRickUIBuilderEditDesignerValidation.Create(AParent, AContext);
end;

function TRickUIBuilderEditDesignerValidation.Required(AValue: Boolean): IRickUIBuilderEditDesignerValidation;
begin
  FContext.Settings.Designer.Required := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerValidation.Required: IRickUIBuilderEditDesignerValidation;
begin
  Result := Required(True);
end;

function TRickUIBuilderEditDesignerValidation.RequirementIndicator(AValue: Boolean): IRickUIBuilderEditDesignerValidation;
begin
  FContext.Settings.Designer.RequirementIndicator := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerValidation.RequirementIndicator: IRickUIBuilderEditDesignerValidation;
begin
  Result := RequirementIndicator(True);
end;

function TRickUIBuilderEditDesignerValidation.Feedback(AValue: TRickUIBuilderEditInvalidFeedback): IRickUIBuilderEditDesignerValidation;
begin
  FContext.Settings.Designer.InvalidFeedback := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerValidation.DefaultMessage(const AValue: string): IRickUIBuilderEditDesignerValidation;
begin
  FContext.Settings.Designer.DefaultInvalidMessage := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerValidation.Invalid(AValue: Boolean): IRickUIBuilderEditDesignerValidation;
begin
  Result := Invalid(AValue, EmptyStr);
end;

function TRickUIBuilderEditDesignerValidation.Invalid(const AMessage: string): IRickUIBuilderEditDesignerValidation;
begin
  Result := Invalid(True, AMessage);
end;

function TRickUIBuilderEditDesignerValidation.Invalid(AValue: Boolean; const AMessage: string): IRickUIBuilderEditDesignerValidation;
var
  LInteraction: TRickUIBuilderEditInteraction;
begin
  FContext.Settings.Designer.HasInvalid := True;
  FContext.Settings.Designer.Invalid := AValue;
  FContext.Settings.Designer.InvalidMessage := AMessage;
  LInteraction := nil;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    LInteraction := TRickUIBuilderEditInteraction(FContext.Interaction);
  if Assigned(LInteraction) then
    LInteraction.SetInvalid(AValue, AMessage);
  Result := Self;
end;

function TRickUIBuilderEditDesignerValidation.HasInvalid: Boolean;
begin
  Result := FContext.Settings.Designer.HasInvalid;
end;

function TRickUIBuilderEditDesignerValidation.InvalidValue: Boolean;
begin
  Result := FContext.Settings.Designer.Invalid;
end;

function TRickUIBuilderEditDesignerValidation.InvalidMessage: string;
begin
  Result := FContext.Settings.Designer.InvalidMessage;
end;

function TRickUIBuilderEditDesignerValidation.RequirementMet(AValue: Boolean): IRickUIBuilderEditDesignerValidation;
var
  LInteraction: TRickUIBuilderEditInteraction;
begin
  FContext.Settings.Designer.HasRequirementMet := True;
  FContext.Settings.Designer.RequirementMet := AValue;
  LInteraction := nil;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    LInteraction := TRickUIBuilderEditInteraction(FContext.Interaction);
  if Assigned(LInteraction) then
    LInteraction.SetRequirementMet(AValue);
  Result := Self;
end;

function TRickUIBuilderEditDesignerValidation.RequirementMet: IRickUIBuilderEditDesignerValidation;
begin
  Result := RequirementMet(True);
end;

function TRickUIBuilderEditDesignerValidation.HasRequirementMet: Boolean;
begin
  Result := FContext.Settings.Designer.HasRequirementMet;
end;

function TRickUIBuilderEditDesignerValidation.RequirementMetValue: Boolean;
begin
  Result := FContext.Settings.Designer.RequirementMet;
end;

function TRickUIBuilderEditDesignerValidation.ToBack: IRickUIBuilderEditDesigner;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

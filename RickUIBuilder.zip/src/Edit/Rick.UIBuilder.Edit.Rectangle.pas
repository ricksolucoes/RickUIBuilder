﻿unit Rick.UIBuilder.Edit.Rectangle;

interface

uses
  System.UITypes,
  FMX.Objects,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces;

type
  TRickUIBuilderEditRetangle = class(TInterfacedObject, IRickUIBuilderEditRetangle)
  strict private
    [weak] FParent: IRickUIBuilderEdit;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
    FPosition: IRickUIBuilderEditRetanglePosition;
    FSize: IRickUIBuilderEditRetangleSize;
    FBackground: IRickUIBuilderEditRetangleBackground;
    FBorder: IRickUIBuilderEditRetangleBorder;
  protected
    constructor Create(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditRetangle; static;
    function Position: IRickUIBuilderEditRetanglePosition;
    function Size: IRickUIBuilderEditRetangleSize;
    function Background: IRickUIBuilderEditRetangleBackground;
    function Border: IRickUIBuilderEditRetangleBorder;
    function CornerRadius(AValue: Single): IRickUIBuilderEditRetangle;
    function Control: TRectangle;
    function ToBack: IRickUIBuilderEdit;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction,
  Rick.UIBuilder.Edit.Rectangle.Position,
  Rick.UIBuilder.Edit.Rectangle.Size,
  Rick.UIBuilder.Edit.Rectangle.Background,
  Rick.UIBuilder.Edit.Rectangle.Border;

constructor TRickUIBuilderEditRetangle.Create(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditRetangle.New(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditRetangle;
begin
  Result := TRickUIBuilderEditRetangle.Create(AParent, AContext);
end;

function TRickUIBuilderEditRetangle.Position: IRickUIBuilderEditRetanglePosition;
begin
  if not Assigned(FPosition) then
    FPosition := TRickUIBuilderEditRetanglePosition.New(Self, FContext);
  Result := FPosition;
end;

function TRickUIBuilderEditRetangle.Size: IRickUIBuilderEditRetangleSize;
begin
  if not Assigned(FSize) then
    FSize := TRickUIBuilderEditRetangleSize.New(Self, FContext);
  Result := FSize;
end;

function TRickUIBuilderEditRetangle.Background: IRickUIBuilderEditRetangleBackground;
begin
  if not Assigned(FBackground) then
    FBackground := TRickUIBuilderEditRetangleBackground.New(Self, FContext);
  Result := FBackground;
end;

function TRickUIBuilderEditRetangle.Border: IRickUIBuilderEditRetangleBorder;
begin
  if not Assigned(FBorder) then
    FBorder := TRickUIBuilderEditRetangleBorder.New(Self, FContext);
  Result := FBorder;
end;

function TRickUIBuilderEditRetangle.CornerRadius(AValue: Single): IRickUIBuilderEditRetangle;
begin
  FContext.Settings.Rectangle.CornerRadius := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditRetangle.Control: TRectangle;
begin
  Result := FContext.Container;
end;

function TRickUIBuilderEditRetangle.ToBack: IRickUIBuilderEdit;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

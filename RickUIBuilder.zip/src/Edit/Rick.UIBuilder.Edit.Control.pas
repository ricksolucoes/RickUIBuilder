﻿unit Rick.UIBuilder.Edit.Control;

interface

uses
  FMX.Edit,
  Rick.UIBuilder.Edit.Types;

type
  TRickUIBuilderEditControl = class(TEdit)
  strict private
    FInputSettings: TRickUIBuilderEditDesignerSettings;
    FConfigured: Boolean;
    FApplyingText: Boolean;
    FPendingCaret: Integer;
    FCaretUpdateQueued: Boolean;
    FPendingGoToEnd: Boolean;
    procedure ApplyPendingCaret;
    procedure QueueCaretUpdate(ACaret: Integer; AGoToEnd: Boolean = False);
    function IsAppendingAtEnd(const AOldText, ANewText: string): Boolean;
    function ChangedCaretPosition(const AOldText, ANewText: string; AOldCaret: Integer): Integer;
    function FormattedCaretPosition(const AValue: string; ARawCaret: Integer): Integer;
    procedure ApplyResolvedText(const AValue, AResolved: string; ACaret: Integer; AAppendAtEnd: Boolean);
  protected
    procedure SetText(const AValue: string); override;
  public
    procedure Configure(const ASettings: TRickUIBuilderEditDesignerSettings);
  end;

implementation

uses
  System.Classes,
  Rick.UIBuilder.Edit.InputRules;

procedure TRickUIBuilderEditControl.Configure(const ASettings: TRickUIBuilderEditDesignerSettings);
begin
  FInputSettings := ASettings;
  FConfigured := True;
end;

procedure TRickUIBuilderEditControl.ApplyPendingCaret;
begin
  FCaretUpdateQueued := False;
  if csDestroying in ComponentState then
    Exit;
  if FPendingGoToEnd then
  begin
    FPendingGoToEnd := False;
    GoToTextEnd;
    Exit;
  end;
  if FPendingCaret > Length(Text) then
    FPendingCaret := Length(Text);
  CaretPosition := FPendingCaret;
  SelLength := 0;
end;

procedure TRickUIBuilderEditControl.QueueCaretUpdate(ACaret: Integer; AGoToEnd: Boolean);
begin
  FPendingCaret := ACaret;
  FPendingGoToEnd := FPendingGoToEnd or AGoToEnd;
  if FCaretUpdateQueued then
    Exit;
  FCaretUpdateQueued := True;
  BeginInvoke(
    procedure
    begin
      ApplyPendingCaret;
    end, Self);
end;

function TRickUIBuilderEditControl.IsAppendingAtEnd(const AOldText, ANewText: string): Boolean;
begin
  Result := IsFocused and (SelLength = 0) and (CaretPosition = Length(AOldText)) and (Length(ANewText) > Length(AOldText)) and (Copy(ANewText, 1, Length(AOldText)) = AOldText);
end;

function TRickUIBuilderEditControl.ChangedCaretPosition(const AOldText, ANewText: string; AOldCaret: Integer): Integer;
var
  LPrefix: Integer;
  LSuffix: Integer;
begin
  if AOldText = ANewText then
    Exit(AOldCaret);
  LPrefix := 0;
  while (LPrefix < Length(AOldText)) and (LPrefix < Length(ANewText)) and (AOldText[LPrefix + 1] = ANewText[LPrefix + 1]) do
    Inc(LPrefix);
  LSuffix := 0;
  while (LSuffix < Length(AOldText) - LPrefix) and (LSuffix < Length(ANewText) - LPrefix) and (AOldText[Length(AOldText) - LSuffix] = ANewText[Length(ANewText) - LSuffix]) do
    Inc(LSuffix);
  Result := Length(ANewText) - LSuffix;
end;

function TRickUIBuilderEditControl.FormattedCaretPosition(const AValue: string; ARawCaret: Integer): Integer;
var
  LPrefix: string;
begin
  if ARawCaret < 0 then
    ARawCaret := 0;
  if ARawCaret > Length(AValue) then
    ARawCaret := Length(AValue);
  LPrefix := Copy(AValue, 1, ARawCaret);
  Result := Length(TRickUIBuilderEditInputRules.FormatTypedValue(LPrefix, FInputSettings));
end;

procedure TRickUIBuilderEditControl.ApplyResolvedText(const AValue, AResolved: string; ACaret: Integer; AAppendAtEnd: Boolean);
begin
  FApplyingText := True;
  try
    inherited SetText(AResolved);
    ACaret := FormattedCaretPosition(AValue, ACaret);
    if AAppendAtEnd then
      GoToTextEnd
    else
      CaretPosition := ACaret;
    SelLength := 0;
    QueueCaretUpdate(ACaret, AAppendAtEnd);
  finally
    FApplyingText := False;
  end;
end;

procedure TRickUIBuilderEditControl.SetText(const AValue: string);
var
  LAppendAtEnd: Boolean;
  LCaret: Integer;
  LOldText: string;
  LResolved: string;
begin
  if FApplyingText or not FConfigured then
  begin
    inherited SetText(AValue);
    Exit;
  end;
  if not TRickUIBuilderEditInputRules.IsTypedValueAllowed(AValue, FInputSettings) then
    Exit;
  LOldText := Text;
  LAppendAtEnd := IsAppendingAtEnd(LOldText, AValue);
  LCaret := ChangedCaretPosition(LOldText, AValue, CaretPosition);
  LResolved := TRickUIBuilderEditInputRules.FormatTypedValue(AValue, FInputSettings);
  if not TRickUIBuilderEditInputRules.IsValueAllowed(LResolved, FInputSettings) then
    Exit;
  ApplyResolvedText(AValue, LResolved, LCaret, LAppendAtEnd);
end;

end.

﻿unit Rick.UIBuilder.Edit.Rectangle.Background;

interface

uses
  System.UITypes,
  FMX.Objects,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces;

type
  TRickUIBuilderEditRetangleBackground = class(TInterfacedObject, IRickUIBuilderEditRetangleBackground)
  strict private
    [weak] FParent: IRickUIBuilderEditRetangle;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
  protected
    constructor Create(const AParent: IRickUIBuilderEditRetangle; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditRetangle; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditRetangleBackground; static;
    function Normal(AValue: TAlphaColor): IRickUIBuilderEditRetangleBackground;
    function Invalid(AValue: TAlphaColor): IRickUIBuilderEditRetangleBackground;
    function ReadOnly(AValue: TAlphaColor): IRickUIBuilderEditRetangleBackground;
    function ToBack: IRickUIBuilderEditRetangle;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction;

constructor TRickUIBuilderEditRetangleBackground.Create(const AParent: IRickUIBuilderEditRetangle; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditRetangleBackground.New(const AParent: IRickUIBuilderEditRetangle; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditRetangleBackground;
begin
  Result := TRickUIBuilderEditRetangleBackground.Create(AParent, AContext);
end;

function TRickUIBuilderEditRetangleBackground.Normal(AValue: TAlphaColor): IRickUIBuilderEditRetangleBackground;
begin
  FContext.Settings.Rectangle.BackgroundColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditRetangleBackground.Invalid(AValue: TAlphaColor): IRickUIBuilderEditRetangleBackground;
begin
  FContext.Settings.Rectangle.InvalidBackgroundColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditRetangleBackground.ReadOnly(AValue: TAlphaColor): IRickUIBuilderEditRetangleBackground;
begin
  FContext.Settings.Rectangle.ReadOnlyBackgroundColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditRetangleBackground.ToBack: IRickUIBuilderEditRetangle;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

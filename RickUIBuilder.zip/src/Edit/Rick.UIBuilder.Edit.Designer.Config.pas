﻿unit Rick.UIBuilder.Edit.Designer.Config;

interface

uses
  System.UITypes,
  FMX.Edit,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces,
  Rick.UIBuilder.Edit.Types;

type
  TRickUIBuilderEditDesignerConfig = class(TInterfacedObject, IRickUIBuilderEditDesignerConfig)
  strict private
    [weak] FParent: IRickUIBuilderEditDesigner;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
  protected
    constructor Create(const AParent: IRickUIBuilderEditDesigner; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditDesigner; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditDesignerConfig; static;
    function ClearButton(AValue: Boolean): IRickUIBuilderEditDesignerConfig; overload;
    function ClearButton: IRickUIBuilderEditDesignerConfig; overload;
    function Password(AValue: Boolean): IRickUIBuilderEditDesignerConfig; overload;
    function Password: IRickUIBuilderEditDesignerConfig; overload;
    function ReadOnly(AValue: Boolean): IRickUIBuilderEditDesignerConfig; overload;
    function ReadOnly: IRickUIBuilderEditDesignerConfig; overload;
    function ToBack: IRickUIBuilderEditDesigner;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction;

constructor TRickUIBuilderEditDesignerConfig.Create(const AParent: IRickUIBuilderEditDesigner; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditDesignerConfig.New(const AParent: IRickUIBuilderEditDesigner; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditDesignerConfig;
begin
  Result := TRickUIBuilderEditDesignerConfig.Create(AParent, AContext);
end;

function TRickUIBuilderEditDesignerConfig.ClearButton(AValue: Boolean): IRickUIBuilderEditDesignerConfig;
begin
  FContext.Settings.Designer.ClearButton := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerConfig.ClearButton: IRickUIBuilderEditDesignerConfig;
begin
  Result := ClearButton(True);
end;

function TRickUIBuilderEditDesignerConfig.Password(AValue: Boolean): IRickUIBuilderEditDesignerConfig;
begin
  FContext.Settings.Designer.Password := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerConfig.Password: IRickUIBuilderEditDesignerConfig;
begin
  Result := Password(True);
end;

function TRickUIBuilderEditDesignerConfig.ReadOnly(AValue: Boolean): IRickUIBuilderEditDesignerConfig;
begin
  FContext.Settings.Designer.ReadOnly := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerConfig.ReadOnly: IRickUIBuilderEditDesignerConfig;
begin
  Result := ReadOnly(True);
end;

function TRickUIBuilderEditDesignerConfig.ToBack: IRickUIBuilderEditDesigner;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

﻿unit Rick.UIBuilder.Edit.InputRules;

interface

{$SCOPEDENUMS ON}

uses
  System.SysUtils,
  System.Character,
  Rick.UIBuilder.Edit.Types;

type
  TRickUIBuilderEditInputRules = class sealed
  strict private
    class function IsBasicLetter(AChar: Char): Boolean; static;
    class function IsPunctuation(AChar: Char): Boolean; static;
    class function IsTextChar(AChar: Char; AAccents, APunctuation: Boolean): Boolean; static;
    class function IsCnpjBaseChar(AChar: Char): Boolean; static;
    class function OnlyDigits(const AValue: string): string; static;
    class function OnlyAlphaNumeric(const AValue: string): string; static;
    class function ApplyPattern(const ARaw, APattern: string): string; static;
    class function FormatPhone(const ARaw: string; AMobile: Boolean): string; static;
    class function DecimalSeparator(const AConfig: TRickUIBuilderEditDesignerSettings): Char; static;
    class function ThousandSeparator(const AConfig: TRickUIBuilderEditDesignerSettings): Char; static;
    class function IsNumberChar(AChar: Char; const AConfig: TRickUIBuilderEditDesignerSettings): Boolean; static;
    class function ValidateNumber(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): Boolean; static;
    class function ValidateNumberCharacters(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings; out ADecimalIndex: Integer): Boolean; static;
    class function FindUrlBoundary(const AValue: string): Integer; static;
    class function ApplyCase(const AValue: string; AMode: TRickUIBuilderEditCaseMode): string; static;
    class function ApplyUrlCase(const AValue: string; AMode: TRickUIBuilderEditUrlCaseMode): string; static;
    class function FormatCPF(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): string; static;
    class function FormatCEP(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): string; static;
    class function FormatPhoneFixed(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): string; static;
    class function FormatPhoneMobile(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): string; static;
    class function FormatCNPJ(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): string; static;
    class function FormatMaskedValue(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): string; static;
    class function IsIntegerAllowed(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): Boolean; static;
    class function IsTextAllowed(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): Boolean; static;
    class function IsEmailAtext(AChar: Char): Boolean; static;
    class function IsEmailCharacterAllowed(AChar: Char; ALocalPart: Boolean): Boolean; static;
    class function IsEmailAllowed(const AValue: string): Boolean; static;
    class function IsEmailComplete(const AValue: string): Boolean; static;
    class function IsEmailLocalPart(const AValue: string): Boolean; static;
    class function IsEmailDomain(const AValue: string): Boolean; static;
    class function IsEmailDomainLabelValid(const AValue: string; AStart, AEnd: Integer): Boolean; static;
    class function FindEmailSeparator(const AValue: string): Integer; static;
    class function IsUrlComplete(const AValue: string): Boolean; static;
    class function StripHttpScheme(var AValue: string): Boolean; static;
    class function FindAuthorityBoundary(const AValue: string): Integer; static;
    class function IsUrlAuthorityValid(const AValue: string): Boolean; static;
    class function IsBracketAuthorityValid(const AValue: string): Boolean; static;
    class function IsHostPortAuthorityValid(const AValue: string): Boolean; static;
    class function IsUrlHostValid(const AValue: string): Boolean; static;
    class function IsDomainHostValid(const AValue: string): Boolean; static;
    class function IsDomainLabelValid(const AValue: string): Boolean; static;
    class function IsIPv4Valid(const AValue: string): Boolean; static;
    class function IsIPv6Valid(const AValue: string): Boolean; static;
    class function IsIPv6PartValid(const AValue: string): Boolean; static;
    class function CountIPv6Parts(const AValue: string; out ACount: Integer): Boolean; static;
    class function IsPortValid(const AValue: string): Boolean; static;
    class function HasCompleteMask(const AValue: string; APreset: TRickUIBuilderEditPreset): Boolean; static;
    class function IsMaskedTypingAllowed(const AValue: string; APreset: TRickUIBuilderEditPreset): Boolean; static;
    class function IsMaskSeparator(AChar: Char; APreset: TRickUIBuilderEditPreset): Boolean; static;
  public
    class function FormatTypedValue(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): string; static;
    class function IsValueAllowed(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): Boolean; static;
    class function IsTypedValueAllowed(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): Boolean; static;
    class function IsPasteAllowed(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): Boolean; static;
    class function IsCompleteValue(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): Boolean; static;
  end;

implementation

uses
  System.StrUtils;

class function TRickUIBuilderEditInputRules.IsBasicLetter(AChar: Char): Boolean;
begin
  Result := ((AChar >= 'A') and (AChar <= 'Z')) or ((AChar >= 'a') and (AChar <= 'z'));
end;

class function TRickUIBuilderEditInputRules.IsPunctuation(AChar: Char): Boolean;
const
  _ASCII_ = '.,;:!?-()[]{}"''`/\|_+=<>*' + '@#$%&~^';
  _UNICODE_ = '—«»’§°ºª';
begin
  Result := (Pos(AChar, _ASCII_) > 0) or (Pos(AChar, _UNICODE_) > 0);
end;

class function TRickUIBuilderEditInputRules.IsTextChar(AChar: Char; AAccents, APunctuation: Boolean): Boolean;
begin
  Result := (AChar = ' ') or IsBasicLetter(AChar);
  if AAccents then
    Result := Result or AChar.IsLetter;
  if APunctuation then
    Result := Result or IsPunctuation(AChar);
end;

class function TRickUIBuilderEditInputRules.IsCnpjBaseChar(AChar: Char): Boolean;
begin
  Result := ((AChar >= '0') and (AChar <= '9')) or ((AChar >= 'A') and (AChar <= 'Z')) or ((AChar >= 'a') and (AChar <= 'z'));
end;

class function TRickUIBuilderEditInputRules.OnlyDigits(const AValue: string): string;
var
  LChar: Char;
begin
  Result := '';
  for LChar in AValue do
    if CharInSet(LChar, ['0'..'9']) then
      Result := Result + LChar;
end;

class function TRickUIBuilderEditInputRules.OnlyAlphaNumeric(const AValue: string): string;
var
  LChar: Char;
begin
  Result := '';
  for LChar in AValue do
    if IsCnpjBaseChar(LChar) then
      Result := Result + UpCase(LChar);
end;

class function TRickUIBuilderEditInputRules.ApplyPattern(const ARaw, APattern: string): string;
var
  I: Integer;
  LRawIndex: Integer;
begin
  Result := '';
  LRawIndex := 1;
  for I := 1 to Length(APattern) do
  begin
    if LRawIndex > Length(ARaw) then
      Break;
    if APattern[I] = '0' then
    begin
      Result := Result + ARaw[LRawIndex];
      Inc(LRawIndex);
    end
    else
      Result := Result + APattern[I];
  end;
end;

class function TRickUIBuilderEditInputRules.FormatPhone(const ARaw: string; AMobile: Boolean): string;
var
  LDigits: string;
  LPattern: string;
begin
  LDigits := OnlyDigits(ARaw);
  if AMobile and (Length(LDigits) > 9) then
    LPattern := '(00) 0 0000-0000'
  else if AMobile then
    LPattern := '0 0000-0000'
  else if Length(LDigits) > 8 then
    LPattern := '(00) 0000-0000'
  else
    LPattern := '0000-0000';
  Result := ApplyPattern(LDigits, LPattern);
end;

class function TRickUIBuilderEditInputRules.DecimalSeparator(const AConfig: TRickUIBuilderEditDesignerSettings): Char;
begin
  if AConfig.NumberFormatMode = TRickUIBuilderEditNumberFormatMode.Locale then
    Exit(FormatSettings.DecimalSeparator);
  Result := AConfig.DecimalSeparator;
end;

class function TRickUIBuilderEditInputRules.ThousandSeparator(const AConfig: TRickUIBuilderEditDesignerSettings): Char;
begin
  if AConfig.NumberFormatMode = TRickUIBuilderEditNumberFormatMode.Locale then
    Exit(FormatSettings.ThousandSeparator);
  Result := AConfig.ThousandSeparator;
end;

class function TRickUIBuilderEditInputRules.IsNumberChar(AChar: Char; const AConfig: TRickUIBuilderEditDesignerSettings): Boolean;
var
  LDecimal: Char;
  LThousand: Char;
begin
  LDecimal := DecimalSeparator(AConfig);
  LThousand := ThousandSeparator(AConfig);
  Result := CharInSet(AChar, ['0'..'9']);
  Result := Result or (AConfig.AllowNegative and (AChar = '-'));
  Result := Result or (AChar = LDecimal);
  Result := Result or (AConfig.UseThousandSeparator and (AChar = LThousand));
end;

class function TRickUIBuilderEditInputRules.ValidateNumberCharacters(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings; out ADecimalIndex: Integer): Boolean;
var
  I: Integer;
  LDecimal: Char;
begin
  ADecimalIndex := 0;
  LDecimal := DecimalSeparator(AConfig);
  for I := 1 to Length(AValue) do
  begin
    if not IsNumberChar(AValue[I], AConfig) then
      Exit(False);
    if (AValue[I] = '-') and (I <> 1) then
      Exit(False);
    if (AValue[I] = LDecimal) and (ADecimalIndex > 0) then
      Exit(False);
    if AValue[I] = LDecimal then
      ADecimalIndex := I;
  end;
  Result := True;
end;

class function TRickUIBuilderEditInputRules.ValidateNumber(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): Boolean;
var
  LDecimalIndex: Integer;
begin
  if not ValidateNumberCharacters(AValue, AConfig, LDecimalIndex) then
    Exit(False);
  if (LDecimalIndex = 0) or (AConfig.DecimalPlaces < 0) then
    Exit(True);
  Result := Length(AValue) - LDecimalIndex <= AConfig.DecimalPlaces;
end;

class function TRickUIBuilderEditInputRules.ApplyCase(const AValue: string; AMode: TRickUIBuilderEditCaseMode): string;
begin
  case AMode of
    TRickUIBuilderEditCaseMode.Uppercase: Result := UpperCase(AValue);
    TRickUIBuilderEditCaseMode.Lowercase: Result := LowerCase(AValue);
  else
    Result := AValue;
  end;
end;

class function TRickUIBuilderEditInputRules.FindUrlBoundary(const AValue: string): Integer;
var
  LScheme: Integer;
begin
  LScheme := Pos('://', AValue);
  Result := Pos('/', AValue);
  if (LScheme > 0) and (Result = LScheme + 1) then
    Result := Pos('/', Copy(AValue, LScheme + 3, MaxInt));
  if (LScheme > 0) and (Result > 0) then
    Inc(Result, LScheme + 2);
  if Result = 0 then
    Result := Pos('?', AValue);
  if Result = 0 then
    Result := Pos('#', AValue);
end;

class function TRickUIBuilderEditInputRules.ApplyUrlCase(const AValue: string; AMode: TRickUIBuilderEditUrlCaseMode): string;
var
  LBoundary: Integer;
begin
  if AMode = TRickUIBuilderEditUrlCaseMode.EntireValue then
    Exit(LowerCase(AValue));
  LBoundary := FindUrlBoundary(AValue);
  if LBoundary = 0 then
    Exit(LowerCase(AValue));
  Result := LowerCase(Copy(AValue, 1, LBoundary - 1)) + Copy(AValue, LBoundary, MaxInt);
end;

class function TRickUIBuilderEditInputRules.FormatCPF(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): string;
begin
  Result := ApplyPattern(OnlyDigits(AValue), '000.000.000-00');
end;

class function TRickUIBuilderEditInputRules.FormatCEP(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): string;
begin
  Result := ApplyPattern(OnlyDigits(AValue), '00000-000');
end;

class function TRickUIBuilderEditInputRules.FormatPhoneFixed(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): string;
begin
  Result := FormatPhone(AValue, False);
end;

class function TRickUIBuilderEditInputRules.FormatPhoneMobile(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): string;
begin
  Result := FormatPhone(AValue, True);
end;

class function TRickUIBuilderEditInputRules.FormatCNPJ(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): string;
var
  LRaw: string;
begin
  LRaw := OnlyAlphaNumeric(AValue);
  if Length(LRaw) > 12 then
    LRaw := Copy(LRaw, 1, 12) + OnlyDigits(Copy(LRaw, 13, 2));
  Result := ApplyPattern(LRaw, '00.000.000/0000-00');
end;

class function TRickUIBuilderEditInputRules.FormatMaskedValue(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): string;
const
  _MAP_: array[TRickUIBuilderEditPreset] of TRickUIBuilderEditInputFormatter = (nil, FormatCPF, FormatCNPJ, FormatCEP, nil, nil, FormatPhoneFixed, FormatPhoneMobile, nil, nil, nil, nil, nil, nil);
var
  LFormatter: TRickUIBuilderEditInputFormatter;
begin
  LFormatter := _MAP_[AConfig.Preset];
  if not Assigned(LFormatter) then
    Exit(AValue);
  Result := LFormatter(AValue, AConfig);
end;

class function TRickUIBuilderEditInputRules.FormatTypedValue(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): string;
begin
  if AConfig.Preset in [TRickUIBuilderEditPreset.CPF, TRickUIBuilderEditPreset.CNPJ, TRickUIBuilderEditPreset.CEP, TRickUIBuilderEditPreset.Phone, TRickUIBuilderEditPreset.Mobile] then
    Result := FormatMaskedValue(AValue, AConfig)
  else if AConfig.Preset = TRickUIBuilderEditPreset.Email then
    Result := LowerCase(AValue)
  else if AConfig.Preset = TRickUIBuilderEditPreset.URL then
    Result := ApplyUrlCase(AValue, AConfig.UrlCaseMode)
  else
    Result := ApplyCase(AValue, AConfig.CaseMode);
  if (AConfig.MaxLength > 0) and (Length(Result) > AConfig.MaxLength) then
    SetLength(Result, AConfig.MaxLength);
end;

class function TRickUIBuilderEditInputRules.IsIntegerAllowed(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): Boolean;
var
  I: Integer;
begin
  Result := True;
  for I := 1 to Length(AValue) do
    if not (CharInSet(AValue[I], ['0'..'9']) or (AConfig.AllowNegative and (AValue[I] = '-') and (I = 1))) then
      Exit(False);
end;

class function TRickUIBuilderEditInputRules.IsTextAllowed(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): Boolean;
var
  LChar: Char;
  LAccents: Boolean;
  LPunctuation: Boolean;
begin
  LAccents := AConfig.Preset in [TRickUIBuilderEditPreset.TextWithAccents, TRickUIBuilderEditPreset.TextPunctuationWithAccents];
  LPunctuation := AConfig.Preset in [TRickUIBuilderEditPreset.TextPunctuationNoAccents, TRickUIBuilderEditPreset.TextPunctuationWithAccents];
  Result := True;
  for LChar in AValue do
    if not IsTextChar(LChar, LAccents, LPunctuation) then
      Exit(False);
end;

class function TRickUIBuilderEditInputRules.IsEmailAtext(AChar: Char): Boolean;
begin
  Result := AChar.IsLetterOrDigit or CharInSet(AChar, ['_', '+', '-']);
end;

class function TRickUIBuilderEditInputRules.FindEmailSeparator(const AValue: string): Integer;
var
  I: Integer;
begin
  Result := 0;
  for I := 1 to Length(AValue) do
    if AValue[I] = '@' then
    begin
      if Result > 0 then
        Exit(-1);
      Result := I;
    end;
end;

class function TRickUIBuilderEditInputRules.IsEmailCharacterAllowed(AChar: Char; ALocalPart: Boolean): Boolean;
begin
  if ALocalPart then
    Exit(IsEmailAtext(AChar) or (AChar = '.'));
  Result := AChar.IsLetterOrDigit or CharInSet(AChar, ['-', '.']);
end;

class function TRickUIBuilderEditInputRules.IsEmailAllowed(const AValue: string): Boolean;
var
  I: Integer;
  LAtIndex: Integer;
  LLocalPart: Boolean;
begin
  LAtIndex := FindEmailSeparator(AValue);
  if LAtIndex < 0 then
    Exit(False);
  for I := 1 to Length(AValue) do
  begin
    if AValue[I] = '@' then
      Continue;
    LLocalPart := (LAtIndex = 0) or (I < LAtIndex);
    if not IsEmailCharacterAllowed(AValue[I], LLocalPart) then
      Exit(False);
  end;
  Result := True;
end;

class function TRickUIBuilderEditInputRules.IsEmailLocalPart(const AValue: string): Boolean;
var
  I: Integer;
begin
  if (AValue = '') or (AValue[1] = '.') or (AValue[Length(AValue)] = '.') or (Pos('..', AValue) > 0) then
    Exit(False);
  for I := 1 to Length(AValue) do
    if not (IsEmailAtext(AValue[I]) or (AValue[I] = '.')) then
      Exit(False);
  Result := True;
end;

class function TRickUIBuilderEditInputRules.IsEmailDomainLabelValid(const AValue: string; AStart, AEnd: Integer): Boolean;
var
  I: Integer;
begin
  if (AEnd < AStart) or (AEnd - AStart + 1 > 63) then
    Exit(False);
  if (AValue[AStart] = '-') or (AValue[AEnd] = '-') then
    Exit(False);
  for I := AStart to AEnd do
    if not (AValue[I].IsLetterOrDigit or (AValue[I] = '-')) then
      Exit(False);
  Result := True;
end;

class function TRickUIBuilderEditInputRules.IsEmailDomain(const AValue: string): Boolean;
var
  I: Integer;
  LLabelStart: Integer;
begin
  if AValue = '' then
    Exit(False);
  LLabelStart := 1;
  for I := 1 to Length(AValue) + 1 do
    if (I > Length(AValue)) or (AValue[I] = '.') then
    begin
      if not IsEmailDomainLabelValid(AValue, LLabelStart, I - 1) then
        Exit(False);
      LLabelStart := I + 1;
    end;
  Result := True;
end;

class function TRickUIBuilderEditInputRules.IsEmailComplete(const AValue: string): Boolean;
var
  LAtIndex: Integer;
  LLocal: string;
  LDomain: string;
begin
  LAtIndex := FindEmailSeparator(AValue);
  if LAtIndex <= 1 then
    Exit(False);
  LLocal := Copy(AValue, 1, LAtIndex - 1);
  LDomain := Copy(AValue, LAtIndex + 1, MaxInt);
  if (LLocal = '') or (LDomain = '') then
    Exit(False);
  if TEncoding.UTF8.GetByteCount(LLocal) > 64 then
    Exit(False);
  if TEncoding.UTF8.GetByteCount(AValue) > 254 then
    Exit(False);
  Result := IsEmailLocalPart(LLocal) and IsEmailDomain(LDomain);
end;

class function TRickUIBuilderEditInputRules.IsPortValid(const AValue: string): Boolean;
var
  LPort: Integer;
  LChar: Char;
begin
  if AValue.Trim.IsEmpty then
    Exit(False);
  for LChar in AValue do
    if not LChar.IsDigit then
      Exit(False);
  Result := TryStrToInt(AValue, LPort) and (LPort >= 0) and (LPort <= 65535);
end;

class function TRickUIBuilderEditInputRules.IsIPv4Valid(const AValue: string): Boolean;
var
  LParts: TArray<string>;
  LPart: string;
  LValue: Integer;
begin
  LParts := AValue.Split(['.']);
  if Length(LParts) <> 4 then
    Exit(False);
  for LPart in LParts do
  begin
    if LPart.Trim.IsEmpty or (Length(LPart) > 3) then
      Exit(False);
    if not TryStrToInt(LPart, LValue) or (LValue < 0) or (LValue > 255) then
      Exit(False);
  end;
  Result := True;
end;

class function TRickUIBuilderEditInputRules.IsIPv6PartValid(const AValue: string): Boolean;
var
  LChar: Char;
begin
  if Length(AValue) > 4 then
    Exit(False);
  for LChar in AValue do
    if not CharInSet(LChar, ['0'..'9', 'a'..'f', 'A'..'F']) then
      Exit(False);
  Result := True;
end;

class function TRickUIBuilderEditInputRules.CountIPv6Parts(const AValue: string; out ACount: Integer): Boolean;
var
  LParts: TArray<string>;
  LPart: string;
begin
  ACount := 0;
  LParts := AValue.Split([':']);
  for LPart in LParts do
    if not LPart.IsEmpty then
    begin
      if not IsIPv6PartValid(LPart) then
        Exit(False);
      Inc(ACount);
    end;
  Result := True;
end;

class function TRickUIBuilderEditInputRules.IsIPv6Valid(const AValue: string): Boolean;
var
  LDoubleColon: Integer;
  LCount: Integer;
begin
  if AValue.Trim.IsEmpty then
    Exit(False);
  LDoubleColon := Pos('::', AValue);
  if (LDoubleColon > 0) and (Pos('::', Copy(AValue, LDoubleColon + 2, MaxInt)) > 0) then
    Exit(False);
  if not CountIPv6Parts(AValue, LCount) then
    Exit(False);
  if LDoubleColon > 0 then
    Exit(LCount < 8);
  Result := LCount = 8;
end;

class function TRickUIBuilderEditInputRules.IsDomainLabelValid(const AValue: string): Boolean;
var
  LChar: Char;
begin
  if AValue.Trim.IsEmpty or (Length(AValue) > 63) then
    Exit(False);
  if (AValue[1] = '-') or (AValue[Length(AValue)] = '-') then
    Exit(False);
  for LChar in AValue do
    if not (LChar.IsLetterOrDigit or (LChar = '-')) then
      Exit(False);
  Result := True;
end;

class function TRickUIBuilderEditInputRules.IsDomainHostValid(const AValue: string): Boolean;
var
  LLabels: TArray<string>;
  LLabel: string;
begin
  if AValue.Trim.IsEmpty then
    Exit(False);
  if SameText(AValue, 'localhost') then
    Exit(True);
  LLabels := AValue.Split(['.']);
  if Length(LLabels) < 2 then
    Exit(False);
  for LLabel in LLabels do
    if not IsDomainLabelValid(LLabel) then
      Exit(False);
  Result := True;
end;

class function TRickUIBuilderEditInputRules.IsUrlHostValid(const AValue: string): Boolean;
var
  LChar: Char;
  LHasDot: Boolean;
begin
  if AValue.Trim.IsEmpty then
    Exit(False);
  LHasDot := False;
  for LChar in AValue do
    if LChar = '.' then
      LHasDot := True;
  if LHasDot and IsIPv4Valid(AValue) then
    Exit(True);
  if LHasDot and AValue[1].IsDigit then
    Exit(False);
  Result := IsDomainHostValid(AValue);
end;

class function TRickUIBuilderEditInputRules.IsBracketAuthorityValid(const AValue: string): Boolean;
var
  LCloseBracket: Integer;
  LHost: string;
  LPort: string;
begin
  LCloseBracket := Pos(']', AValue);
  if LCloseBracket = 0 then
    Exit(False);
  LHost := Copy(AValue, 2, LCloseBracket - 2);
  if not IsIPv6Valid(LHost) then
    Exit(False);
  LPort := Copy(AValue, LCloseBracket + 1, MaxInt);
  if LPort.IsEmpty then
    Exit(True);
  if LPort[1] <> ':' then
    Exit(False);
  Result := IsPortValid(Copy(LPort, 2, MaxInt));
end;

class function TRickUIBuilderEditInputRules.IsHostPortAuthorityValid(const AValue: string): Boolean;
var
  LColon: Integer;
  LHost: string;
  LPort: string;
begin
  LColon := LastDelimiter(':', AValue);
  if LColon = 0 then
    Exit(IsUrlHostValid(AValue));
  LHost := Copy(AValue, 1, LColon - 1);
  LPort := Copy(AValue, LColon + 1, MaxInt);
  if Pos(':', LHost) > 0 then
    Exit(False);
  Result := IsUrlHostValid(LHost) and IsPortValid(LPort);
end;

class function TRickUIBuilderEditInputRules.IsUrlAuthorityValid(const AValue: string): Boolean;
begin
  if AValue.Trim.IsEmpty or (Pos('@', AValue) > 0) then
    Exit(False);
  if AValue[1] = '[' then
    Exit(IsBracketAuthorityValid(AValue));
  Result := IsHostPortAuthorityValid(AValue);
end;

class function TRickUIBuilderEditInputRules.StripHttpScheme(var AValue: string): Boolean;
begin
  Result := True;
  if Pos('://', AValue) = 0 then
    Exit;
  if StartsText('https://', AValue) then
    Delete(AValue, 1, Length('https://'))
  else if StartsText('http://', AValue) then
    Delete(AValue, 1, Length('http://'))
  else
    Result := False;
end;

class function TRickUIBuilderEditInputRules.FindAuthorityBoundary(const AValue: string): Integer;
var
  LCandidate: Integer;
begin
  Result := Length(AValue) + 1;
  LCandidate := Pos('/', AValue);
  if (LCandidate > 0) and (LCandidate < Result) then
    Result := LCandidate;
  LCandidate := Pos('?', AValue);
  if (LCandidate > 0) and (LCandidate < Result) then
    Result := LCandidate;
  LCandidate := Pos('#', AValue);
  if (LCandidate > 0) and (LCandidate < Result) then
    Result := LCandidate;
end;

class function TRickUIBuilderEditInputRules.IsUrlComplete(const AValue: string): Boolean;
var
  LValue: string;
  LBoundary: Integer;
  LAuthority: string;
begin
  LValue := AValue;
  if LValue.Trim.IsEmpty or (LValue <> LValue.Trim) then
    Exit(False);
  if not StripHttpScheme(LValue) then
    Exit(False);
  LBoundary := FindAuthorityBoundary(LValue);
  LAuthority := Copy(LValue, 1, LBoundary - 1);
  Result := IsUrlAuthorityValid(LAuthority);
end;

class function TRickUIBuilderEditInputRules.IsValueAllowed(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): Boolean;
begin
  if (AConfig.MaxLength > 0) and (Length(AValue) > AConfig.MaxLength) then
    Exit(False);
  case AConfig.Preset of
    TRickUIBuilderEditPreset.IntegerNumber: Result := IsIntegerAllowed(AValue, AConfig);
    TRickUIBuilderEditPreset.FloatNumber: Result := ValidateNumber(AValue, AConfig);
    TRickUIBuilderEditPreset.Email: Result := IsEmailAllowed(AValue);
    TRickUIBuilderEditPreset.TextNoAccents, TRickUIBuilderEditPreset.TextPunctuationNoAccents, TRickUIBuilderEditPreset.TextWithAccents, TRickUIBuilderEditPreset.TextPunctuationWithAccents: Result := IsTextAllowed(AValue, AConfig);
  else
    Result := True;
  end;
end;

class function TRickUIBuilderEditInputRules.IsMaskSeparator(AChar: Char; APreset: TRickUIBuilderEditPreset): Boolean;
begin
  case APreset of
    TRickUIBuilderEditPreset.CPF: Result := CharInSet(AChar, ['.', '-']);
    TRickUIBuilderEditPreset.CNPJ: Result := CharInSet(AChar, ['.', '/', '-']);
    TRickUIBuilderEditPreset.CEP: Result := AChar = '-';
    TRickUIBuilderEditPreset.Phone, TRickUIBuilderEditPreset.Mobile: Result := CharInSet(AChar, ['(', ')', ' ', '-']);
  else
    Result := False;
  end;
end;

class function TRickUIBuilderEditInputRules.IsMaskedTypingAllowed(const AValue: string; APreset: TRickUIBuilderEditPreset): Boolean;
var
  LChar: Char;
  LAlphaIndex: Integer;
begin
  LAlphaIndex := 0;
  for LChar in AValue do
  begin
    if IsCnpjBaseChar(LChar) then
      Inc(LAlphaIndex)
    else if not IsMaskSeparator(LChar, APreset) then
      Exit(False);
    if (APreset <> TRickUIBuilderEditPreset.CNPJ) and IsBasicLetter(LChar) then
      Exit(False);
    if (APreset = TRickUIBuilderEditPreset.CNPJ) and (LAlphaIndex > 12) and IsBasicLetter(LChar) then
      Exit(False);
  end;
  Result := True;
end;

class function TRickUIBuilderEditInputRules.HasCompleteMask(const AValue: string; APreset: TRickUIBuilderEditPreset): Boolean;
begin
  case APreset of
    TRickUIBuilderEditPreset.CPF: Result := Length(AValue) = 14;
    TRickUIBuilderEditPreset.CNPJ: Result := Length(AValue) = 18;
    TRickUIBuilderEditPreset.CEP: Result := Length(AValue) = 9;
    TRickUIBuilderEditPreset.Phone: Result := Length(AValue) in [9, 14];
    TRickUIBuilderEditPreset.Mobile: Result := Length(AValue) in [11, 16];
  else
    Result := True;
  end;
end;

class function TRickUIBuilderEditInputRules.IsTypedValueAllowed(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): Boolean;
begin
  if AConfig.Preset in [TRickUIBuilderEditPreset.CPF, TRickUIBuilderEditPreset.CNPJ, TRickUIBuilderEditPreset.CEP, TRickUIBuilderEditPreset.Phone, TRickUIBuilderEditPreset.Mobile] then
    Exit(IsMaskedTypingAllowed(AValue, AConfig.Preset));
  Result := IsValueAllowed(AValue, AConfig);
end;

class function TRickUIBuilderEditInputRules.IsPasteAllowed(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): Boolean;
var
  LFormatted: string;
begin
  if not IsValueAllowed(AValue, AConfig) then
    Exit(False);
  if not (AConfig.Preset in [TRickUIBuilderEditPreset.CPF, TRickUIBuilderEditPreset.CNPJ, TRickUIBuilderEditPreset.CEP, TRickUIBuilderEditPreset.Phone, TRickUIBuilderEditPreset.Mobile]) then
    Exit(True);
  LFormatted := FormatTypedValue(AValue, AConfig);
  Result := HasCompleteMask(AValue, AConfig.Preset) and (AValue = LFormatted);
end;

class function TRickUIBuilderEditInputRules.IsCompleteValue(const AValue: string; const AConfig: TRickUIBuilderEditDesignerSettings): Boolean;
var
  LFormatted: string;
begin
  if AValue.Trim.IsEmpty then
    Exit(not AConfig.Required);
  if AConfig.Preset in [TRickUIBuilderEditPreset.CPF, TRickUIBuilderEditPreset.CNPJ, TRickUIBuilderEditPreset.CEP, TRickUIBuilderEditPreset.Phone, TRickUIBuilderEditPreset.Mobile] then
  begin
    LFormatted := FormatTypedValue(AValue, AConfig);
    Exit((AValue = LFormatted) and HasCompleteMask(LFormatted, AConfig.Preset));
  end;
  if AConfig.Preset = TRickUIBuilderEditPreset.Email then
    Exit(IsEmailComplete(AValue));
  if AConfig.Preset = TRickUIBuilderEditPreset.URL then
    Exit(IsUrlComplete(AValue));
  Result := True;
end;

end.

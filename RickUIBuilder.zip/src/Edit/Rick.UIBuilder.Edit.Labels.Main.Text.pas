﻿unit Rick.UIBuilder.Edit.Labels.Main.Text;

interface

uses
  System.UITypes,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces;

type
  TRickUIBuilderEditLabelMainText = class(TInterfacedObject, IRickUIBuilderEditLabelMainText)
  strict private
    [weak] FParent: IRickUIBuilderEditLabelMain;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
    FColor: IRickUIBuilderEditLabelMainTextColor;
  protected
    constructor Create(const AParent: IRickUIBuilderEditLabelMain; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditLabelMain; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLabelMainText; static;
    function Value(const AValue: string): IRickUIBuilderEditLabelMainText;
    function Size(AValue: Single): IRickUIBuilderEditLabelMainText;
    function Color: IRickUIBuilderEditLabelMainTextColor;
    function ToBack: IRickUIBuilderEditLabelMain;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction,
  Rick.UIBuilder.Edit.Labels.Main.Text.Color;

constructor TRickUIBuilderEditLabelMainText.Create(const AParent: IRickUIBuilderEditLabelMain; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditLabelMainText.New(const AParent: IRickUIBuilderEditLabelMain; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLabelMainText;
begin
  Result := TRickUIBuilderEditLabelMainText.Create(AParent, AContext);
end;

function TRickUIBuilderEditLabelMainText.Value(const AValue: string): IRickUIBuilderEditLabelMainText;
begin
  FContext.Settings.Labels.MainText := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditLabelMainText.Size(AValue: Single): IRickUIBuilderEditLabelMainText;
begin
  FContext.Settings.Labels.MainFontSize := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditLabelMainText.Color: IRickUIBuilderEditLabelMainTextColor;
begin
  if not Assigned(FColor) then
    FColor := TRickUIBuilderEditLabelMainTextColor.New(Self, FContext);
  Result := FColor;
end;

function TRickUIBuilderEditLabelMainText.ToBack: IRickUIBuilderEditLabelMain;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

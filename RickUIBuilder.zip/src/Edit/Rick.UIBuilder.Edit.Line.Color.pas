﻿unit Rick.UIBuilder.Edit.Line.Color;

interface

uses
  System.UITypes,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces;

type
  TRickUIBuilderEditLineColor = class(TInterfacedObject, IRickUIBuilderEditLineColor)
  strict private
    [weak] FParent: IRickUIBuilderEditLine;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
  protected
    constructor Create(const AParent: IRickUIBuilderEditLine; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditLine; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLineColor; static;
    function Normal(AValue: TAlphaColor): IRickUIBuilderEditLineColor;
    function Focus(AValue: TAlphaColor): IRickUIBuilderEditLineColor;
    function Invalid(AValue: TAlphaColor): IRickUIBuilderEditLineColor;
    function ReadOnly(AValue: TAlphaColor): IRickUIBuilderEditLineColor;
    function ToBack: IRickUIBuilderEditLine;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction;

constructor TRickUIBuilderEditLineColor.Create(const AParent: IRickUIBuilderEditLine; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditLineColor.New(const AParent: IRickUIBuilderEditLine; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLineColor;
begin
  Result := TRickUIBuilderEditLineColor.Create(AParent, AContext);
end;

function TRickUIBuilderEditLineColor.Normal(AValue: TAlphaColor): IRickUIBuilderEditLineColor;
begin
  FContext.Settings.Line.NormalColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditLineColor.Focus(AValue: TAlphaColor): IRickUIBuilderEditLineColor;
begin
  FContext.Settings.Line.FocusColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditLineColor.Invalid(AValue: TAlphaColor): IRickUIBuilderEditLineColor;
begin
  FContext.Settings.Line.InvalidColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditLineColor.ReadOnly(AValue: TAlphaColor): IRickUIBuilderEditLineColor;
begin
  FContext.Settings.Line.ReadOnlyColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditLineColor.ToBack: IRickUIBuilderEditLine;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

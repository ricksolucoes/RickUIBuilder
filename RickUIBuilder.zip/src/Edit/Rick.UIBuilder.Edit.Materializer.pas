﻿unit Rick.UIBuilder.Edit.Materializer;

interface

uses
  System.UITypes,
  FMX.Edit,
  FMX.Layouts,
  FMX.Objects,
  FMX.StdCtrls,
  FMX.Types,
  Rick.UIBuilder.Edit.Context;

type
  TRickUIBuilderEditMaterializer = class sealed
  strict private
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
    constructor Create(AContext: TRickUIBuilderEditContext);
    procedure Materialize(AParent: TFmxObject);
    function CreateCore(AParent: TFmxObject): TRectangle;
    procedure CreateLabels(AContainer: TRectangle);
    procedure CreateInteraction(AParent: TFmxObject);
    function CreateContainer(AParent: TFmxObject): TRectangle;
    function CreateMainLabel(AContainer: TRectangle): TLabel;
    function CreateEditBackground(AContainer: TRectangle): TRectangle;
    function CreateEditControl(AContainer: TRectangle): TEdit;
    function CreateCounter(AContainer: TRectangle): TLabel;
    function CreateErrorLabel(AContainer: TRectangle): TLabel;
    function CreateLine(AContainer: TRectangle): TRectangle;
    function CreatePath(AParent: TFmxObject; const AData: string; AColor: TAlphaColor): TPath;
    function CreateActionArea(AContainer: TRectangle): TLayout;
    procedure CreateActions(AContainer: TRectangle);
  public
    class procedure Build(AParent: TFmxObject; AContext: TRickUIBuilderEditContext); static;
  end;

implementation

uses
  FMX.Controls,
  FMX.Graphics,
  Rick.UIBuilder.Edit.Control,
  Rick.UIBuilder.Edit.Interaction,
  Rick.UIBuilder.Edit.Types;

constructor TRickUIBuilderEditMaterializer.Create(AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class procedure TRickUIBuilderEditMaterializer.Build(AParent: TFmxObject; AContext: TRickUIBuilderEditContext);
var
  LMaterializer: TRickUIBuilderEditMaterializer;
begin
  LMaterializer := TRickUIBuilderEditMaterializer.Create(AContext);
  try
    LMaterializer.Materialize(AParent);
  finally
    LMaterializer.Free;
  end;
end;

procedure TRickUIBuilderEditMaterializer.Materialize(AParent: TFmxObject);
var
  LContainer: TRectangle;
begin
  LContainer := CreateCore(AParent);
  CreateLabels(LContainer);
  CreateActions(LContainer);
  CreateInteraction(AParent);
end;

function TRickUIBuilderEditMaterializer.CreateCore(AParent: TFmxObject): TRectangle;
var
  LEditBackground: TRectangle;
  LEdit: TEdit;
  LLine: TRectangle;
begin
  Result := CreateContainer(AParent);
  LEditBackground := CreateEditBackground(Result);
  LEditBackground.SendToBack;
  LEdit := CreateEditControl(Result);
  LLine := CreateLine(Result);
  FContext.AttachCore(Result, LEditBackground, LEdit, LLine);
end;

procedure TRickUIBuilderEditMaterializer.CreateLabels(AContainer: TRectangle);
var
  LLabel: TLabel;
  LCounter: TLabel;
  LError: TLabel;
begin
  LLabel := CreateMainLabel(AContainer);
  LCounter := CreateCounter(AContainer);
  LError := CreateErrorLabel(AContainer);
  FContext.AttachLabels(LLabel, LCounter, LError);
end;

procedure TRickUIBuilderEditMaterializer.CreateInteraction(AParent: TFmxObject);
var
  LInteraction: TRickUIBuilderEditInteraction;
begin
  LInteraction := TRickUIBuilderEditInteraction.Create(AParent);
  FContext.Interaction := LInteraction;
  LInteraction.Configure(FContext, FContext.Settings);
  LInteraction.ConfigureIcons;
end;

function TRickUIBuilderEditMaterializer.CreateContainer(AParent: TFmxObject): TRectangle;
begin
  Result := TRectangle.Create(AParent);
  Result.Parent := AParent;
end;

function TRickUIBuilderEditMaterializer.CreateMainLabel(AContainer: TRectangle): TLabel;
begin
  Result := TLabel.Create(AContainer);
  Result.Parent := AContainer;
  Result.StyledSettings := Result.StyledSettings - [TStyledSetting.Size, TStyledSetting.FontColor];
  Result.HitTest := False;
end;

function TRickUIBuilderEditMaterializer.CreateEditBackground(AContainer: TRectangle): TRectangle;
begin
  Result := TRectangle.Create(AContainer);
  Result.Parent := AContainer;
  Result.Stroke.Kind := TBrushKind.None;
  Result.HitTest := False;
end;

function TRickUIBuilderEditMaterializer.CreateEditControl(AContainer: TRectangle): TEdit;
var
  LEdit: TRickUIBuilderEditControl;
begin
  LEdit := TRickUIBuilderEditControl.Create(AContainer);
  LEdit.Configure(FContext.Settings.Designer);
  Result := LEdit;
  Result.Parent := AContainer;
  Result.StyleLookup := 'transparentedit';
  Result.StyledSettings := Result.StyledSettings - [TStyledSetting.Size, TStyledSetting.FontColor];
end;

function TRickUIBuilderEditMaterializer.CreateCounter(AContainer: TRectangle): TLabel;
begin
  Result := TLabel.Create(AContainer);
  Result.Parent := AContainer;
  Result.TextSettings.HorzAlign := TTextAlign.Trailing;
  Result.HitTest := False;
end;

function TRickUIBuilderEditMaterializer.CreateErrorLabel(AContainer: TRectangle): TLabel;
begin
  Result := TLabel.Create(AContainer);
  Result.Parent := AContainer;
  Result.StyledSettings := Result.StyledSettings - [TStyledSetting.Family, TStyledSetting.Size, TStyledSetting.Style, TStyledSetting.FontColor];
  Result.Visible := False;
  Result.HitTest := False;
end;

function TRickUIBuilderEditMaterializer.CreateLine(AContainer: TRectangle): TRectangle;
begin
  Result := TRectangle.Create(AContainer);
  Result.Parent := AContainer;
  Result.Stroke.Kind := TBrushKind.None;
  Result.HitTest := False;
end;

function TRickUIBuilderEditMaterializer.CreatePath(AParent: TFmxObject; const AData: string; AColor: TAlphaColor): TPath;
begin
  Result := TPath.Create(AParent);
  Result.Parent := AParent;
  Result.Align := TAlignLayout.Center;
  Result.Data.Data := AData;
  Result.WrapMode := TPathWrapMode.Fit;
  Result.Fill.Color := AColor;
  Result.Stroke.Kind := TBrushKind.None;
  Result.HitTest := False;
end;

function TRickUIBuilderEditMaterializer.CreateActionArea(AContainer: TRectangle): TLayout;
begin
  Result := TLayout.Create(AContainer);
  Result.Parent := AContainer;
  Result.HitTest := True;
  Result.Cursor := crHandPoint;
  Result.BringToFront;
end;

procedure TRickUIBuilderEditMaterializer.CreateActions(AContainer: TRectangle);
var
  LIcons: TRickUIBuilderEditIconSettings;
  LAlert: TPath;
  LClearArea: TLayout;
  LClearPath: TPath;
  LPasswordArea: TLayout;
  LPasswordPath: TPath;
  LRequirementPath: TPath;
begin
  LIcons := FContext.Settings.Config.Icons;
  LClearArea := CreateActionArea(AContainer);
  LClearPath := CreatePath(LClearArea, LIcons.Paths.Clear, LIcons.Colors.ClearColor);
  LPasswordArea := CreateActionArea(AContainer);
  LPasswordPath := CreatePath(LPasswordArea, LIcons.Paths.VisibilityOff, LIcons.Colors.PasswordColor);
  LRequirementPath := CreatePath(AContainer, LIcons.Paths.RequirementNotMet, LIcons.Colors.RequirementColor);
  LRequirementPath.Align := TAlignLayout.None;
  LAlert := CreatePath(AContainer, LIcons.Paths.Alert, LIcons.Colors.AlertColor);
  LAlert.Align := TAlignLayout.None;
  LAlert.Visible := False;
  FContext.AttachActions(LAlert, LClearArea, LClearPath, LPasswordArea, LPasswordPath, LRequirementPath);
end;

end.

﻿unit Rick.UIBuilder.Edit.Config;

interface

uses
  System.UITypes,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces,
  Rick.UIBuilder.Edit.Types;

type
  TRickUIBuilderEditConfig = class(TInterfacedObject, IRickUIBuilderEditConfig)
  strict private
    [weak] FParent: IRickUIBuilderEdit;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
    FIcons: IRickUIBuilderEditConfigIcons;
  protected
    constructor Create(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditConfig; static;
    function Appearance(AValue: TRickUIBuilderEditAppearance): IRickUIBuilderEditConfig;
    function Icons: IRickUIBuilderEditConfigIcons;
    function ToBack: IRickUIBuilderEdit;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction,
  Rick.UIBuilder.Edit.Config.Icons;

constructor TRickUIBuilderEditConfig.Create(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditConfig.New(const AParent: IRickUIBuilderEdit; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditConfig;
begin
  Result := TRickUIBuilderEditConfig.Create(AParent, AContext);
end;

function TRickUIBuilderEditConfig.Appearance(AValue: TRickUIBuilderEditAppearance): IRickUIBuilderEditConfig;
begin
  FContext.Settings.Config.Appearance := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditConfig.Icons: IRickUIBuilderEditConfigIcons;
begin
  if not Assigned(FIcons) then
    FIcons := TRickUIBuilderEditConfigIcons.New(Self, FContext);
  Result := FIcons;
end;

function TRickUIBuilderEditConfig.ToBack: IRickUIBuilderEdit;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

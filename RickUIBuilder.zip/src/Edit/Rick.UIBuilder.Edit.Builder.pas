﻿unit Rick.UIBuilder.Edit.Builder;

interface

uses
  FMX.Types,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces;

type
  TRickUIBuilderEdit = class(TInterfacedObject, IRickUIBuilderEdit)
  strict private
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
    FRectangle: IRickUIBuilderEditRetangle;
    FLabels: IRickUIBuilderEditLabel;
    FEdit: IRickUIBuilderEditDesigner;
    FLine: IRickUIBuilderEditLine;
    FConfig: IRickUIBuilderEditConfig;
  protected
    constructor Create;
  public
    class function New: IRickUIBuilderEdit; static;
    function Rectangle: IRickUIBuilderEditRetangle;
    function Labels: IRickUIBuilderEditLabel;
    function Edit: IRickUIBuilderEditDesigner;
    function Line: IRickUIBuilderEditLine;
    function Config: IRickUIBuilderEditConfig;
    function Build(AParent: TFmxObject): IRickUIBuilderEdit;
  end;

implementation

uses
  Rick.UIBuilder.Edit.Rectangle,
  Rick.UIBuilder.Edit.Labels,
  Rick.UIBuilder.Edit.Designer,
  Rick.UIBuilder.Edit.Line,
  Rick.UIBuilder.Edit.Config,
  Rick.UIBuilder.Edit.Materializer;

constructor TRickUIBuilderEdit.Create;
begin
  inherited Create;
  FContext := TRickUIBuilderEditContext.Create;
  FContextRef := FContext as IInterface;
end;

class function TRickUIBuilderEdit.New: IRickUIBuilderEdit;
begin
  Result := TRickUIBuilderEdit.Create;
end;

function TRickUIBuilderEdit.Rectangle: IRickUIBuilderEditRetangle;
begin
  if not Assigned(FRectangle) then
    FRectangle := TRickUIBuilderEditRetangle.New(Self, FContext);
  Result := FRectangle;
end;

function TRickUIBuilderEdit.Labels: IRickUIBuilderEditLabel;
begin
  if not Assigned(FLabels) then
    FLabels := TRickUIBuilderEditLabel.New(Self, FContext);
  Result := FLabels;
end;

function TRickUIBuilderEdit.Edit: IRickUIBuilderEditDesigner;
begin
  if not Assigned(FEdit) then
    FEdit := TRickUIBuilderEditDesigner.New(Self, FContext);
  Result := FEdit;
end;

function TRickUIBuilderEdit.Line: IRickUIBuilderEditLine;
begin
  if not Assigned(FLine) then
    FLine := TRickUIBuilderEditLine.New(Self, FContext);
  Result := FLine;
end;

function TRickUIBuilderEdit.Config: IRickUIBuilderEditConfig;
begin
  if not Assigned(FConfig) then
    FConfig := TRickUIBuilderEditConfig.New(Self, FContext);
  Result := FConfig;
end;

function TRickUIBuilderEdit.Build(AParent: TFmxObject): IRickUIBuilderEdit;
begin
  TRickUIBuilderEditMaterializer.Build(AParent, FContext);
  Result := Self;
end;

end.

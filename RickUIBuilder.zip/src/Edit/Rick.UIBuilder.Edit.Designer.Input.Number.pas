﻿unit Rick.UIBuilder.Edit.Designer.Input.Number;

interface

uses
  System.UITypes,
  FMX.Edit,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces,
  Rick.UIBuilder.Edit.Types;

type
  TRickUIBuilderEditDesignerInputNumber = class(TInterfacedObject, IRickUIBuilderEditDesignerInputNumber)
  strict private
    [weak] FParent: IRickUIBuilderEditDesignerInput;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
  protected
    constructor Create(const AParent: IRickUIBuilderEditDesignerInput; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditDesignerInput; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditDesignerInputNumber; static;
    function AllowNegative(AValue: Boolean): IRickUIBuilderEditDesignerInputNumber; overload;
    function AllowNegative: IRickUIBuilderEditDesignerInputNumber; overload;
    function DecimalPlaces(AValue: Integer): IRickUIBuilderEditDesignerInputNumber;
    function FormatMode(AValue: TRickUIBuilderEditNumberFormatMode): IRickUIBuilderEditDesignerInputNumber;
    function DecimalSeparator(AValue: Char): IRickUIBuilderEditDesignerInputNumber;
    function ThousandSeparator(AValue: Char): IRickUIBuilderEditDesignerInputNumber;
    function UseThousandSeparator(AValue: Boolean): IRickUIBuilderEditDesignerInputNumber; overload;
    function UseThousandSeparator: IRickUIBuilderEditDesignerInputNumber; overload;
    function ToBack: IRickUIBuilderEditDesignerInput;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction;

constructor TRickUIBuilderEditDesignerInputNumber.Create(const AParent: IRickUIBuilderEditDesignerInput; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditDesignerInputNumber.New(const AParent: IRickUIBuilderEditDesignerInput; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditDesignerInputNumber;
begin
  Result := TRickUIBuilderEditDesignerInputNumber.Create(AParent, AContext);
end;

function TRickUIBuilderEditDesignerInputNumber.AllowNegative(AValue: Boolean): IRickUIBuilderEditDesignerInputNumber;
begin
  FContext.Settings.Designer.AllowNegative := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerInputNumber.AllowNegative: IRickUIBuilderEditDesignerInputNumber;
begin
  Result := AllowNegative(True);
end;

function TRickUIBuilderEditDesignerInputNumber.DecimalPlaces(AValue: Integer): IRickUIBuilderEditDesignerInputNumber;
begin
  FContext.Settings.Designer.DecimalPlaces := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerInputNumber.FormatMode(AValue: TRickUIBuilderEditNumberFormatMode): IRickUIBuilderEditDesignerInputNumber;
begin
  FContext.Settings.Designer.NumberFormatMode := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerInputNumber.DecimalSeparator(AValue: Char): IRickUIBuilderEditDesignerInputNumber;
begin
  FContext.Settings.Designer.DecimalSeparator := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerInputNumber.ThousandSeparator(AValue: Char): IRickUIBuilderEditDesignerInputNumber;
begin
  FContext.Settings.Designer.ThousandSeparator := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerInputNumber.UseThousandSeparator(AValue: Boolean): IRickUIBuilderEditDesignerInputNumber;
begin
  FContext.Settings.Designer.UseThousandSeparator := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerInputNumber.UseThousandSeparator: IRickUIBuilderEditDesignerInputNumber;
begin
  Result := UseThousandSeparator(True);
end;

function TRickUIBuilderEditDesignerInputNumber.ToBack: IRickUIBuilderEditDesignerInput;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

﻿unit Rick.UIBuilder.Edit.Labels.Main.Text.Color;

interface

uses
  System.UITypes,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces;

type
  TRickUIBuilderEditLabelMainTextColor = class(TInterfacedObject, IRickUIBuilderEditLabelMainTextColor)
  strict private
    [weak] FParent: IRickUIBuilderEditLabelMainText;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
  protected
    constructor Create(const AParent: IRickUIBuilderEditLabelMainText; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditLabelMainText; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLabelMainTextColor; static;
    function Text(AValue: TAlphaColor): IRickUIBuilderEditLabelMainTextColor;
    function Invalid(AValue: TAlphaColor): IRickUIBuilderEditLabelMainTextColor;
    function ReadOnly(AValue: TAlphaColor): IRickUIBuilderEditLabelMainTextColor;
    function ToBack: IRickUIBuilderEditLabelMainText;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction;

constructor TRickUIBuilderEditLabelMainTextColor.Create(const AParent: IRickUIBuilderEditLabelMainText; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditLabelMainTextColor.New(const AParent: IRickUIBuilderEditLabelMainText; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLabelMainTextColor;
begin
  Result := TRickUIBuilderEditLabelMainTextColor.Create(AParent, AContext);
end;

function TRickUIBuilderEditLabelMainTextColor.Text(AValue: TAlphaColor): IRickUIBuilderEditLabelMainTextColor;
begin
  FContext.Settings.Labels.MainTextColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditLabelMainTextColor.Invalid(AValue: TAlphaColor): IRickUIBuilderEditLabelMainTextColor;
begin
  FContext.Settings.Labels.MainInvalidTextColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditLabelMainTextColor.ReadOnly(AValue: TAlphaColor): IRickUIBuilderEditLabelMainTextColor;
begin
  FContext.Settings.Labels.MainReadOnlyTextColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditLabelMainTextColor.ToBack: IRickUIBuilderEditLabelMainText;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

﻿unit Rick.UIBuilder.Edit.Config.Icons.Colors;

interface

uses
  System.UITypes,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces,
  Rick.UIBuilder.Edit.Types;

type
  TRickUIBuilderEditConfigIconColors = class(TInterfacedObject, IRickUIBuilderEditConfigIconColors)
  strict private
    [weak] FParent: IRickUIBuilderEditConfigIcons;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
  protected
    constructor Create(const AParent: IRickUIBuilderEditConfigIcons; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditConfigIcons; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditConfigIconColors; static;
    function Default(AValue: TAlphaColor): IRickUIBuilderEditConfigIconColors;
    function Alert(AValue: TAlphaColor): IRickUIBuilderEditConfigIconColors;
    function Clear(AValue: TAlphaColor): IRickUIBuilderEditConfigIconColors;
    function Password(AValue: TAlphaColor): IRickUIBuilderEditConfigIconColors;
    function Requirement(AValue: TAlphaColor): IRickUIBuilderEditConfigIconColors;
    function ToBack: IRickUIBuilderEditConfigIcons;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction;

constructor TRickUIBuilderEditConfigIconColors.Create(const AParent: IRickUIBuilderEditConfigIcons; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditConfigIconColors.New(const AParent: IRickUIBuilderEditConfigIcons; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditConfigIconColors;
begin
  Result := TRickUIBuilderEditConfigIconColors.Create(AParent, AContext);
end;

function TRickUIBuilderEditConfigIconColors.Default(AValue: TAlphaColor): IRickUIBuilderEditConfigIconColors;
begin
  FContext.Settings.Config.Icons.Colors.DefaultColor := AValue;
  FContext.Settings.Config.Icons.Colors.AlertColor := AValue;
  FContext.Settings.Config.Icons.Colors.ClearColor := AValue;
  FContext.Settings.Config.Icons.Colors.PasswordColor := AValue;
  FContext.Settings.Config.Icons.Colors.RequirementColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditConfigIconColors.Alert(AValue: TAlphaColor): IRickUIBuilderEditConfigIconColors;
begin
  FContext.Settings.Config.Icons.Colors.AlertColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditConfigIconColors.Clear(AValue: TAlphaColor): IRickUIBuilderEditConfigIconColors;
begin
  FContext.Settings.Config.Icons.Colors.ClearColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditConfigIconColors.Password(AValue: TAlphaColor): IRickUIBuilderEditConfigIconColors;
begin
  FContext.Settings.Config.Icons.Colors.PasswordColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditConfigIconColors.Requirement(AValue: TAlphaColor): IRickUIBuilderEditConfigIconColors;
begin
  FContext.Settings.Config.Icons.Colors.RequirementColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditConfigIconColors.ToBack: IRickUIBuilderEditConfigIcons;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

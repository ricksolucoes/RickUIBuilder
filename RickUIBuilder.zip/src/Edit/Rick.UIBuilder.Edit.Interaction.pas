﻿unit Rick.UIBuilder.Edit.Interaction;

interface

uses
  System.Classes,
  System.UITypes,
  FMX.Controls,
  FMX.Edit,
  FMX.Layouts,
  FMX.Objects,
  FMX.StdCtrls,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Types;

type
  TRickUIBuilderEditInteraction = class(TComponent)
  strict private
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
    FSettings: TRickUIBuilderEditSettings;
    FContainer: TRectangle;
    FEditBackground: TRectangle;
    FEdit: TEdit;
    FLabel: TLabel;
    FCounter: TLabel;
    FErrorLabel: TLabel;
    FLine: TRectangle;
    FAlertPath: TPath;
    FClearArea: TLayout;
    FClearPath: TPath;
    FPasswordArea: TLayout;
    FPasswordPath: TPath;
    FRequirementPath: TPath;
    FLastValidText: string;
    FUpdating: Boolean;
    FInvalid: Boolean;
    FInvalidFromInput: Boolean;
    FRequirementMet: Boolean;
    function LabelHeight: Single;
    function EditHeight: Single;
    function ErrorHeight: Single;
    function EffectiveHeight: Single;
    procedure ApplyRectangleConfig;
    procedure ApplyLabelConfig;
    procedure ApplyEditConfig;
    procedure ApplyLineConfig;
    procedure ApplyIconConfig;
    procedure UpdateGeometry;
    procedure ApplyNormalState;
    procedure ApplyFocusState;
    procedure ApplyInvalidState;
    procedure ApplyCurrentState;
    procedure UpdateInvalidPresentation;
    procedure UpdateCounter;
    procedure UpdateClearVisibility;
    procedure UpdateActionLayout;
    procedure UpdateEditAreaWidth(ALeft: Single);
    procedure PlaceActionArea(AControl: TControl; var ALeft: Single);
    procedure PlaceActionPath(AControl: TControl; var ALeft: Single);
    procedure UpdatePasswordIcon;
    procedure UpdateRequirementIcon;
    procedure AcceptCurrentText;
    procedure SignalInvalidInput;
    function ShouldShowErrorLabel(const AMessage: string): Boolean;
    function ShouldShowAlertIcon: Boolean;
    procedure HandleEnter(ASender: TObject);
    procedure HandleExit(ASender: TObject);
    function ResolveChangedText(const AText: string; out AResolved: string): Boolean;
    function IsOverflowAttempt(const AText: string): Boolean;
    procedure HandleChange(ASender: TObject);
    procedure HandleRejectedChange(const AText: string);
    procedure HandleResolvedChange(const AResolved: string; ATypingAtEnd: Boolean);
    procedure QueueCaretToEnd;
    procedure HandleClear(ASender: TObject);
    procedure HandlePassword(ASender: TObject);
    procedure BindActionHandlers;
    procedure ClearHandlers;
    procedure DetachVisuals;
  protected
    procedure Notification(AComponent: TComponent; Operation: TOperation); override;
  public
    destructor Destroy; override;
    procedure Configure(AContext: TRickUIBuilderEditContext; const ASettings: TRickUIBuilderEditSettings);
    procedure ConfigureIcons;
    procedure SyncSettings(const ASettings: TRickUIBuilderEditSettings);
    procedure SetText(const AValue: string);
    procedure Clear;
    procedure SetInvalid(AValue: Boolean; const AMessage: string = '');
    procedure SetRequirementMet(AValue: Boolean);
  end;

implementation

uses
  System.Math,
  System.SysUtils,
  Rick.UIBuilder.Edit.Control,
  Rick.UIBuilder.Edit.InputRules;

destructor TRickUIBuilderEditInteraction.Destroy;
begin
  ClearHandlers;
  if Assigned(FContext) then
    FContext.Detach(FContainer);
  inherited Destroy;
end;

procedure TRickUIBuilderEditInteraction.ClearHandlers;
begin
  if Assigned(FEdit) then
  begin
    FEdit.OnEnter := nil;
    FEdit.OnExit := nil;
    FEdit.OnChangeTracking := nil;
  end;
  if Assigned(FClearArea) then
    FClearArea.OnClick := nil;
  if Assigned(FClearPath) then
    FClearPath.OnClick := nil;
  if Assigned(FPasswordArea) then
    FPasswordArea.OnClick := nil;
  if Assigned(FPasswordPath) then
    FPasswordPath.OnClick := nil;
end;

procedure TRickUIBuilderEditInteraction.DetachVisuals;
begin
  ClearHandlers;
  FContainer := nil;
  FEditBackground := nil;
  FEdit := nil;
  FLabel := nil;
  FCounter := nil;
  FErrorLabel := nil;
  FLine := nil;
  FAlertPath := nil;
  FClearArea := nil;
  FClearPath := nil;
  FPasswordArea := nil;
  FPasswordPath := nil;
  FRequirementPath := nil;
end;

procedure TRickUIBuilderEditInteraction.Notification(AComponent: TComponent; Operation: TOperation);
var
  LContainer: TRectangle;
begin
  LContainer := FContainer;
  inherited Notification(AComponent, Operation);
  if (Operation <> opRemove) or ((AComponent <> FContainer) and (AComponent <> FEdit)) then
    Exit;
  if Assigned(FContext) then
    FContext.Detach(LContainer);
  DetachVisuals;
end;

procedure TRickUIBuilderEditInteraction.Configure(AContext: TRickUIBuilderEditContext; const ASettings: TRickUIBuilderEditSettings);
begin
  FContext := AContext;
  FContextRef := AContext as IInterface;
  FSettings := ASettings;
  FContainer := AContext.Container;
  FEditBackground := AContext.EditBackground;
  FEdit := AContext.EditControl;
  FContainer.FreeNotification(Self);
  FEdit.FreeNotification(Self);
  FLabel := AContext.MainLabel;
  FCounter := AContext.CounterLabel;
  FErrorLabel := AContext.ErrorLabel;
  FLine := AContext.LineControl;
  FEdit.OnEnter := HandleEnter;
  FEdit.OnExit := HandleExit;
  FEdit.OnChangeTracking := HandleChange;
end;

procedure TRickUIBuilderEditInteraction.ConfigureIcons;
begin
  FAlertPath := FContext.AlertPath;
  FClearArea := FContext.ClearArea;
  FClearPath := FContext.ClearPath;
  FPasswordArea := FContext.PasswordArea;
  FPasswordPath := FContext.PasswordPath;
  FRequirementPath := FContext.RequirementPath;
  BindActionHandlers;
  SyncSettings(FSettings);
  SetText(FSettings.Designer.Text);
  if FSettings.Designer.HasInvalid then
    SetInvalid(FSettings.Designer.Invalid, FSettings.Designer.InvalidMessage);
  if FSettings.Designer.HasRequirementMet then
    SetRequirementMet(FSettings.Designer.RequirementMet);
end;

procedure TRickUIBuilderEditInteraction.BindActionHandlers;
begin
  FClearArea.OnClick := HandleClear;
  FClearPath.HitTest := True;
  FClearPath.OnClick := HandleClear;
  FPasswordArea.OnClick := HandlePassword;
  FPasswordPath.HitTest := True;
  FPasswordPath.OnClick := HandlePassword;
end;

procedure TRickUIBuilderEditInteraction.SyncSettings(const ASettings: TRickUIBuilderEditSettings);
begin
  FSettings := ASettings;
  ApplyRectangleConfig;
  ApplyLabelConfig;
  ApplyEditConfig;
  ApplyLineConfig;
  ApplyIconConfig;
  UpdateGeometry;
  UpdateCounter;
  UpdateClearVisibility;
  UpdatePasswordIcon;
  UpdateRequirementIcon;
  UpdateInvalidPresentation;
  ApplyCurrentState;
end;

function TRickUIBuilderEditInteraction.LabelHeight: Single;
begin
  Result := Max(18, FSettings.Labels.MainFontSize + 6);
end;

function TRickUIBuilderEditInteraction.EditHeight: Single;
begin
  Result := Max(24, FSettings.Designer.FontSize + 10);
end;

function TRickUIBuilderEditInteraction.ErrorHeight: Single;
begin
  Result := Max(18, FSettings.Labels.ErrorFontSize + 6);
end;

function TRickUIBuilderEditInteraction.EffectiveHeight: Single;
var
  LMinimum: Single;
begin
  LMinimum := 3 + LabelHeight + 3 + EditHeight + 8;
  if (FSettings.Labels.ErrorText <> '') or (FSettings.Designer.DefaultInvalidMessage <> '') then
    LMinimum := LMinimum + FSettings.Labels.ErrorSpacing + ErrorHeight;
  Result := Max(FSettings.Rectangle.Height, LMinimum);
end;

procedure TRickUIBuilderEditInteraction.ApplyRectangleConfig;
begin
  FContainer.XRadius := FSettings.Rectangle.CornerRadius;
  FContainer.YRadius := FSettings.Rectangle.CornerRadius;
  FContainer.Stroke.Thickness := FSettings.Rectangle.BorderThickness;
  if FSettings.Config.Appearance = TRickUIBuilderEditAppearance.Underline then
    FContainer.Stroke.Kind := TBrushKind.None
  else
    FContainer.Stroke.Kind := TBrushKind.Solid;
end;

procedure TRickUIBuilderEditInteraction.ApplyLabelConfig;
begin
  FLabel.Text := FSettings.Labels.MainText;
  FLabel.TextSettings.Font.Size := FSettings.Labels.MainFontSize;
  if not FInvalid then
    FErrorLabel.Text := FSettings.Labels.ErrorText;
  FErrorLabel.TextSettings.Font.Size := FSettings.Labels.ErrorFontSize;
  FErrorLabel.TextSettings.FontColor := FSettings.Labels.ErrorTextColor;
  FErrorLabel.TextSettings.Font.Style := FSettings.Labels.ErrorFontStyles;
  if FSettings.Labels.ErrorFontFamily <> '' then
    FErrorLabel.TextSettings.Font.Family := FSettings.Labels.ErrorFontFamily;
end;

procedure TRickUIBuilderEditInteraction.ApplyEditConfig;
begin
  FEditBackground.Fill.Color := FSettings.Designer.BackgroundColor;
  FEdit.TextSettings.Font.Size := FSettings.Designer.FontSize;
  FEdit.Password := FSettings.Designer.Password;
  FEdit.ReadOnly := FSettings.Designer.ReadOnly;
  if FEdit is TRickUIBuilderEditControl then
    TRickUIBuilderEditControl(FEdit).Configure(FSettings.Designer);
end;

procedure TRickUIBuilderEditInteraction.ApplyLineConfig;
begin
  FLine.Height := FSettings.Line.Thickness;
  FLine.Visible := FSettings.Config.Appearance = TRickUIBuilderEditAppearance.Underline;
end;

procedure TRickUIBuilderEditInteraction.ApplyIconConfig;
begin
  FAlertPath.Fill.Color := FSettings.Config.Icons.Colors.AlertColor;
  FClearPath.Fill.Color := FSettings.Config.Icons.Colors.ClearColor;
  FPasswordPath.Fill.Color := FSettings.Config.Icons.Colors.PasswordColor;
  FRequirementPath.Fill.Color := FSettings.Config.Icons.Colors.RequirementColor;
  FAlertPath.Data.Data := FSettings.Config.Icons.Paths.Alert;
  FClearPath.Data.Data := FSettings.Config.Icons.Paths.Clear;
  FAlertPath.Width := FSettings.Config.Icons.Size;
  FAlertPath.Height := FSettings.Config.Icons.Size;
  FClearPath.Width := FSettings.Config.Icons.Size;
  FClearPath.Height := FSettings.Config.Icons.Size;
  FPasswordPath.Width := FSettings.Config.Icons.Size;
  FPasswordPath.Height := FSettings.Config.Icons.Size;
  FRequirementPath.Width := FSettings.Config.Icons.Size;
  FRequirementPath.Height := FSettings.Config.Icons.Size;
end;

procedure TRickUIBuilderEditInteraction.UpdateGeometry;
var
  LHeight: Single;
begin
  LHeight := EffectiveHeight;
  FContainer.SetBounds(FSettings.Rectangle.Left, FSettings.Rectangle.Top, FSettings.Rectangle.Width, LHeight);
  FLabel.SetBounds(12, 3, FContainer.Width - 24, LabelHeight);
  FEditBackground.SetBounds(8, 6 + LabelHeight, FContainer.Width - 16, EditHeight);
  FEdit.SetBounds(8, 6 + LabelHeight, FContainer.Width - 16, EditHeight);
  FCounter.SetBounds(FContainer.Width - 72, LHeight - 20, 64, 16);
  FErrorLabel.SetBounds(12, 6 + LabelHeight + EditHeight + FSettings.Labels.ErrorSpacing, FContainer.Width - 24, ErrorHeight);
  FLine.SetBounds(8, 6 + LabelHeight + EditHeight, FContainer.Width - 16, FSettings.Line.Thickness);
  FClearArea.SetBounds(FContainer.Width - 40, 6 + LabelHeight, 32, EditHeight);
  FPasswordArea.SetBounds(FContainer.Width - 40, 6 + LabelHeight, 32, EditHeight);
  UpdateActionLayout;
end;

procedure TRickUIBuilderEditInteraction.ApplyNormalState;
begin
  if FSettings.Designer.ReadOnly then
  begin
    FContainer.Fill.Color := FSettings.Rectangle.ReadOnlyBackgroundColor;
    FContainer.Stroke.Color := FSettings.Rectangle.ReadOnlyBorderColor;
    FLabel.TextSettings.FontColor := FSettings.Labels.MainReadOnlyTextColor;
    FEdit.TextSettings.FontColor := FSettings.Designer.ReadOnlyTextColor;
    FLine.Fill.Color := FSettings.Line.ReadOnlyColor;
    Exit;
  end;
  FContainer.Fill.Color := FSettings.Rectangle.BackgroundColor;
  FContainer.Stroke.Color := FSettings.Rectangle.BorderColor;
  FLabel.TextSettings.FontColor := FSettings.Labels.MainTextColor;
  FEdit.TextSettings.FontColor := FSettings.Designer.TextColor;
  FLine.Fill.Color := FSettings.Line.NormalColor;
end;

procedure TRickUIBuilderEditInteraction.ApplyFocusState;
begin
  if FSettings.Designer.ReadOnly then
  begin
    ApplyNormalState;
    Exit;
  end;
  FContainer.Fill.Color := FSettings.Rectangle.BackgroundColor;
  FContainer.Stroke.Color := FSettings.Rectangle.FocusBorderColor;
  FLabel.TextSettings.FontColor := FSettings.Labels.MainTextColor;
  FEdit.TextSettings.FontColor := FSettings.Designer.TextColor;
  FLine.Fill.Color := FSettings.Line.FocusColor;
end;

procedure TRickUIBuilderEditInteraction.ApplyInvalidState;
begin
  FContainer.Fill.Color := FSettings.Rectangle.InvalidBackgroundColor;
  FContainer.Stroke.Color := FSettings.Rectangle.InvalidBorderColor;
  FLabel.TextSettings.FontColor := FSettings.Labels.MainInvalidTextColor;
  FEdit.TextSettings.FontColor := FSettings.Designer.TextColor;
  FLine.Fill.Color := FSettings.Line.InvalidColor;
end;

procedure TRickUIBuilderEditInteraction.ApplyCurrentState;
begin
  if FInvalid then
    ApplyInvalidState
  else if FEdit.IsFocused then
    ApplyFocusState
  else
    ApplyNormalState;
end;

procedure TRickUIBuilderEditInteraction.UpdateInvalidPresentation;
begin
  FErrorLabel.Visible := FInvalid and ShouldShowErrorLabel(FErrorLabel.Text);
  FAlertPath.Visible := FInvalid and ShouldShowAlertIcon;
  if FErrorLabel.Visible and (FContainer.Height < FErrorLabel.Position.Y + FErrorLabel.Height + 8) then
    FContainer.Height := FErrorLabel.Position.Y + FErrorLabel.Height + 8;
  UpdateActionLayout;
end;

function TRickUIBuilderEditInteraction.ResolveChangedText(const AText: string; out AResolved: string): Boolean;
begin
  Result := TRickUIBuilderEditInputRules.IsTypedValueAllowed(AText, FSettings.Designer);
  if not Result then
    Exit;
  AResolved := TRickUIBuilderEditInputRules.FormatTypedValue(AText, FSettings.Designer);
  Result := TRickUIBuilderEditInputRules.IsValueAllowed(AResolved, FSettings.Designer);
end;

function TRickUIBuilderEditInteraction.IsOverflowAttempt(const AText: string): Boolean;
begin
  Result := (Length(AText) > Length(FLastValidText)) and TRickUIBuilderEditInputRules.IsCompleteValue(FLastValidText, FSettings.Designer);
end;

procedure TRickUIBuilderEditInteraction.HandleRejectedChange(const AText: string);
var
  LOverflow: Boolean;
begin
  LOverflow := IsOverflowAttempt(AText);
  SetText(FLastValidText);
  if not LOverflow then
    SignalInvalidInput;
end;

procedure TRickUIBuilderEditInteraction.HandleResolvedChange(const AResolved: string; ATypingAtEnd: Boolean);
begin
  if AResolved <> FEdit.Text then
  begin
    SetText(AResolved);
    if ATypingAtEnd then
      QueueCaretToEnd;
  end
  else
    AcceptCurrentText;
  if FInvalidFromInput then
    SetInvalid(False);
end;

procedure TRickUIBuilderEditInteraction.HandleChange(ASender: TObject);
var
  LResolved: string;
  LTypingAtEnd: Boolean;
begin
  if FUpdating then
    Exit;
  LTypingAtEnd := (FEdit.SelLength = 0) and (Length(FEdit.Text) > Length(FLastValidText)) and (Copy(FEdit.Text, 1, Length(FLastValidText)) = FLastValidText);
  if not ResolveChangedText(FEdit.Text, LResolved) then
  begin
    HandleRejectedChange(FEdit.Text);
    Exit;
  end;
  HandleResolvedChange(LResolved, LTypingAtEnd);
end;

procedure TRickUIBuilderEditInteraction.QueueCaretToEnd;
begin
  FEdit.BeginInvoke(
    procedure
    begin
      if not (csDestroying in FEdit.ComponentState) then
      begin
        FEdit.GoToTextEnd;
        FEdit.SelLength := 0;
      end;
    end, FEdit);
end;

procedure TRickUIBuilderEditInteraction.SetText(const AValue: string);
var
  LValue: string;
begin
  LValue := TRickUIBuilderEditInputRules.FormatTypedValue(AValue, FSettings.Designer);
  if not TRickUIBuilderEditInputRules.IsValueAllowed(LValue, FSettings.Designer) then
    Exit;
  FUpdating := True;
  try
    FEdit.Text := LValue;
    FLastValidText := LValue;
    UpdateCounter;
    UpdateClearVisibility;
  finally
    FUpdating := False;
  end;
end;

procedure TRickUIBuilderEditInteraction.Clear;
begin
  SetText('');
  SetInvalid(False);
  FEdit.SetFocus;
end;

procedure TRickUIBuilderEditInteraction.HandleClear(ASender: TObject);
begin
  Clear;
end;

procedure TRickUIBuilderEditInteraction.HandlePassword(ASender: TObject);
begin
  FEdit.Password := not FEdit.Password;
  UpdatePasswordIcon;
  FEdit.SetFocus;
end;

procedure TRickUIBuilderEditInteraction.HandleEnter(ASender: TObject);
begin
  ApplyCurrentState;
end;

procedure TRickUIBuilderEditInteraction.HandleExit(ASender: TObject);
begin
  if not TRickUIBuilderEditInputRules.IsCompleteValue(FEdit.Text, FSettings.Designer) then
    SignalInvalidInput;
  ApplyCurrentState;
  FEdit.CaretPosition := 0;
  FEdit.SelLength := 0;
end;

function TRickUIBuilderEditInteraction.ShouldShowErrorLabel(const AMessage: string): Boolean;
begin
  Result := (AMessage <> '') and (FSettings.Designer.InvalidFeedback <> TRickUIBuilderEditInvalidFeedback.IconOnly);
end;

function TRickUIBuilderEditInteraction.ShouldShowAlertIcon: Boolean;
begin
  Result := FSettings.Designer.InvalidFeedback <> TRickUIBuilderEditInvalidFeedback.AlertOnly;
end;

procedure TRickUIBuilderEditInteraction.SetInvalid(AValue: Boolean; const AMessage: string);
begin
  FInvalid := AValue;
  FInvalidFromInput := False;
  FErrorLabel.Text := AMessage;
  UpdateInvalidPresentation;
  ApplyCurrentState;
end;

procedure TRickUIBuilderEditInteraction.SignalInvalidInput;
begin
  SetInvalid(True, FSettings.Designer.DefaultInvalidMessage);
  FInvalidFromInput := True;
end;

procedure TRickUIBuilderEditInteraction.SetRequirementMet(AValue: Boolean);
begin
  FRequirementMet := AValue;
  UpdateRequirementIcon;
end;

procedure TRickUIBuilderEditInteraction.AcceptCurrentText;
begin
  FLastValidText := FEdit.Text;
  UpdateCounter;
  UpdateClearVisibility;
end;

procedure TRickUIBuilderEditInteraction.UpdateCounter;
begin
  FCounter.Visible := FSettings.Labels.CounterEnabled and (FSettings.Designer.MaxLength > 0);
  if FCounter.Visible then
    FCounter.Text := Format('%d/%d', [Length(FEdit.Text), FSettings.Designer.MaxLength]);
end;

procedure TRickUIBuilderEditInteraction.UpdateClearVisibility;
begin
  FClearArea.Visible := FSettings.Designer.ClearButton and (FEdit.Text <> '') and not FSettings.Designer.ReadOnly;
  UpdateActionLayout;
end;

procedure TRickUIBuilderEditInteraction.PlaceActionArea(AControl: TControl; var ALeft: Single);
begin
  if not AControl.Visible then
    Exit;
  AControl.Position.X := ALeft;
  ALeft := ALeft - 32;
end;

procedure TRickUIBuilderEditInteraction.PlaceActionPath(AControl: TControl; var ALeft: Single);
begin
  if not AControl.Visible then
    Exit;
  AControl.Position.X := ALeft + ((32 - FSettings.Config.Icons.Size) / 2);
  AControl.Position.Y := 6 + LabelHeight + ((EditHeight - FSettings.Config.Icons.Size) / 2);
  ALeft := ALeft - 32;
end;

procedure TRickUIBuilderEditInteraction.UpdateEditAreaWidth(ALeft: Single);
var
  LWidth: Single;
begin
  LWidth := ALeft - 8;
  if LWidth < 40 then
    LWidth := 40;
  FEdit.Width := LWidth;
  FEditBackground.Width := LWidth;
end;

procedure TRickUIBuilderEditInteraction.UpdateActionLayout;
var
  LActionLeft: Single;
  LEditRight: Single;
begin
  LActionLeft := FContainer.Width - 40;
  LEditRight := FContainer.Width - 8;
  PlaceActionArea(FClearArea, LActionLeft);
  PlaceActionArea(FPasswordArea, LActionLeft);
  PlaceActionPath(FRequirementPath, LActionLeft);
  PlaceActionPath(FAlertPath, LActionLeft);
  if LActionLeft < FContainer.Width - 40 then
    LEditRight := LActionLeft + 32;
  UpdateEditAreaWidth(LEditRight);
end;

procedure TRickUIBuilderEditInteraction.UpdatePasswordIcon;
begin
  FPasswordArea.Visible := FSettings.Designer.Password;
  if not FPasswordArea.Visible then
    Exit;
  if FEdit.Password then
    FPasswordPath.Data.Data := FSettings.Config.Icons.Paths.VisibilityOff
  else
    FPasswordPath.Data.Data := FSettings.Config.Icons.Paths.Visibility;
end;

procedure TRickUIBuilderEditInteraction.UpdateRequirementIcon;
begin
  FRequirementPath.Visible := FSettings.Designer.RequirementIndicator;
  if not FRequirementPath.Visible then
  begin
    UpdateActionLayout;
    Exit;
  end;
  if FRequirementMet then
    FRequirementPath.Data.Data := FSettings.Config.Icons.Paths.RequirementMet
  else
    FRequirementPath.Data.Data := FSettings.Config.Icons.Paths.RequirementNotMet;
  UpdateActionLayout;
end;

end.

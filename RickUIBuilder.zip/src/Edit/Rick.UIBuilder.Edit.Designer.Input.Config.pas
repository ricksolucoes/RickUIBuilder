﻿unit Rick.UIBuilder.Edit.Designer.Input.Config;

interface

uses
  System.UITypes,
  FMX.Edit,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces,
  Rick.UIBuilder.Edit.Types;

type
  TRickUIBuilderEditDesignerInputConfig = class(TInterfacedObject, IRickUIBuilderEditDesignerInputConfig)
  strict private
    [weak] FParent: IRickUIBuilderEditDesignerInput;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
  protected
    constructor Create(const AParent: IRickUIBuilderEditDesignerInput; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditDesignerInput; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditDesignerInputConfig; static;
    function Preset(AValue: TRickUIBuilderEditPreset): IRickUIBuilderEditDesignerInputConfig;
    function CaseMode(AValue: TRickUIBuilderEditCaseMode): IRickUIBuilderEditDesignerInputConfig;
    function UrlCaseMode(AValue: TRickUIBuilderEditUrlCaseMode): IRickUIBuilderEditDesignerInputConfig;
    function MaxLength(AValue: Integer): IRickUIBuilderEditDesignerInputConfig;
    function ToBack: IRickUIBuilderEditDesignerInput;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction;

constructor TRickUIBuilderEditDesignerInputConfig.Create(const AParent: IRickUIBuilderEditDesignerInput; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditDesignerInputConfig.New(const AParent: IRickUIBuilderEditDesignerInput; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditDesignerInputConfig;
begin
  Result := TRickUIBuilderEditDesignerInputConfig.Create(AParent, AContext);
end;

function TRickUIBuilderEditDesignerInputConfig.Preset(AValue: TRickUIBuilderEditPreset): IRickUIBuilderEditDesignerInputConfig;
begin
  FContext.Settings.Designer.Preset := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerInputConfig.CaseMode(AValue: TRickUIBuilderEditCaseMode): IRickUIBuilderEditDesignerInputConfig;
begin
  FContext.Settings.Designer.CaseMode := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerInputConfig.UrlCaseMode(AValue: TRickUIBuilderEditUrlCaseMode): IRickUIBuilderEditDesignerInputConfig;
begin
  FContext.Settings.Designer.UrlCaseMode := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerInputConfig.MaxLength(AValue: Integer): IRickUIBuilderEditDesignerInputConfig;
begin
  FContext.Settings.Designer.MaxLength := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerInputConfig.ToBack: IRickUIBuilderEditDesignerInput;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

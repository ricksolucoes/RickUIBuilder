﻿unit Rick.UIBuilder.Edit.Rectangle.Size;

interface

uses
  System.UITypes,
  FMX.Objects,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces;

type
  TRickUIBuilderEditRetangleSize = class(TInterfacedObject, IRickUIBuilderEditRetangleSize)
  strict private
    [weak] FParent: IRickUIBuilderEditRetangle;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
  protected
    constructor Create(const AParent: IRickUIBuilderEditRetangle; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditRetangle; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditRetangleSize; static;
    function Width(AValue: Single): IRickUIBuilderEditRetangleSize;
    function Height(AValue: Single): IRickUIBuilderEditRetangleSize;
    function ToBack: IRickUIBuilderEditRetangle;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction;

constructor TRickUIBuilderEditRetangleSize.Create(const AParent: IRickUIBuilderEditRetangle; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditRetangleSize.New(const AParent: IRickUIBuilderEditRetangle; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditRetangleSize;
begin
  Result := TRickUIBuilderEditRetangleSize.Create(AParent, AContext);
end;

function TRickUIBuilderEditRetangleSize.Width(AValue: Single): IRickUIBuilderEditRetangleSize;
begin
  FContext.Settings.Rectangle.Width := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditRetangleSize.Height(AValue: Single): IRickUIBuilderEditRetangleSize;
begin
  FContext.Settings.Rectangle.Height := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditRetangleSize.ToBack: IRickUIBuilderEditRetangle;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

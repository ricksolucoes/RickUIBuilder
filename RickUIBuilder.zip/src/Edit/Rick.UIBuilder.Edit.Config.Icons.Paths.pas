﻿unit Rick.UIBuilder.Edit.Config.Icons.Paths;

interface

uses
  System.UITypes,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces,
  Rick.UIBuilder.Edit.Types;

type
  TRickUIBuilderEditConfigIconPaths = class(TInterfacedObject, IRickUIBuilderEditConfigIconPaths)
  strict private
    [weak] FParent: IRickUIBuilderEditConfigIcons;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
  protected
    constructor Create(const AParent: IRickUIBuilderEditConfigIcons; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditConfigIcons; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditConfigIconPaths; static;
    function Alert(const AValue: string): IRickUIBuilderEditConfigIconPaths;
    function Clear(const AValue: string): IRickUIBuilderEditConfigIconPaths;
    function Visibility(const AValue: string): IRickUIBuilderEditConfigIconPaths;
    function VisibilityOff(const AValue: string): IRickUIBuilderEditConfigIconPaths;
    function RequirementMet(const AValue: string): IRickUIBuilderEditConfigIconPaths;
    function RequirementNotMet(const AValue: string): IRickUIBuilderEditConfigIconPaths;
    function ToBack: IRickUIBuilderEditConfigIcons;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction;

constructor TRickUIBuilderEditConfigIconPaths.Create(const AParent: IRickUIBuilderEditConfigIcons; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditConfigIconPaths.New(const AParent: IRickUIBuilderEditConfigIcons; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditConfigIconPaths;
begin
  Result := TRickUIBuilderEditConfigIconPaths.Create(AParent, AContext);
end;

function TRickUIBuilderEditConfigIconPaths.Alert(const AValue: string): IRickUIBuilderEditConfigIconPaths;
begin
  FContext.Settings.Config.Icons.Paths.Alert := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditConfigIconPaths.Clear(const AValue: string): IRickUIBuilderEditConfigIconPaths;
begin
  FContext.Settings.Config.Icons.Paths.Clear := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditConfigIconPaths.Visibility(const AValue: string): IRickUIBuilderEditConfigIconPaths;
begin
  FContext.Settings.Config.Icons.Paths.Visibility := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditConfigIconPaths.VisibilityOff(const AValue: string): IRickUIBuilderEditConfigIconPaths;
begin
  FContext.Settings.Config.Icons.Paths.VisibilityOff := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditConfigIconPaths.RequirementMet(const AValue: string): IRickUIBuilderEditConfigIconPaths;
begin
  FContext.Settings.Config.Icons.Paths.RequirementMet := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditConfigIconPaths.RequirementNotMet(const AValue: string): IRickUIBuilderEditConfigIconPaths;
begin
  FContext.Settings.Config.Icons.Paths.RequirementNotMet := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditConfigIconPaths.ToBack: IRickUIBuilderEditConfigIcons;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

﻿unit Rick.UIBuilder.Edit.Designer.Input.Text.Color;

interface

uses
  System.UITypes,
  FMX.Edit,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces,
  Rick.UIBuilder.Edit.Types;

type
  TRickUIBuilderEditDesignerInputTextColor = class(TInterfacedObject, IRickUIBuilderEditDesignerInputTextColor)
  strict private
    [weak] FParent: IRickUIBuilderEditDesignerInputText;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
  protected
    constructor Create(const AParent: IRickUIBuilderEditDesignerInputText; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditDesignerInputText; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditDesignerInputTextColor; static;
    function Background(AValue: TAlphaColor): IRickUIBuilderEditDesignerInputTextColor;
    function Text(AValue: TAlphaColor): IRickUIBuilderEditDesignerInputTextColor;
    function ReadOnly(AValue: TAlphaColor): IRickUIBuilderEditDesignerInputTextColor;
    function ToBack: IRickUIBuilderEditDesignerInputText;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction;

constructor TRickUIBuilderEditDesignerInputTextColor.Create(const AParent: IRickUIBuilderEditDesignerInputText; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditDesignerInputTextColor.New(const AParent: IRickUIBuilderEditDesignerInputText; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditDesignerInputTextColor;
begin
  Result := TRickUIBuilderEditDesignerInputTextColor.Create(AParent, AContext);
end;

function TRickUIBuilderEditDesignerInputTextColor.Background(AValue: TAlphaColor): IRickUIBuilderEditDesignerInputTextColor;
begin
  FContext.Settings.Designer.BackgroundColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerInputTextColor.Text(AValue: TAlphaColor): IRickUIBuilderEditDesignerInputTextColor;
begin
  FContext.Settings.Designer.TextColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerInputTextColor.ReadOnly(AValue: TAlphaColor): IRickUIBuilderEditDesignerInputTextColor;
begin
  FContext.Settings.Designer.ReadOnlyTextColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditDesignerInputTextColor.ToBack: IRickUIBuilderEditDesignerInputText;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

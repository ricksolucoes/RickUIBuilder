﻿unit Rick.UIBuilder.Edit.Rectangle.Position;

interface

uses
  System.UITypes,
  FMX.Objects,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces;

type
  TRickUIBuilderEditRetanglePosition = class(TInterfacedObject, IRickUIBuilderEditRetanglePosition)
  strict private
    [weak] FParent: IRickUIBuilderEditRetangle;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
  protected
    constructor Create(const AParent: IRickUIBuilderEditRetangle; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditRetangle; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditRetanglePosition; static;
    function Left(AValue: Single): IRickUIBuilderEditRetanglePosition;
    function Top(AValue: Single): IRickUIBuilderEditRetanglePosition;
    function ToBack: IRickUIBuilderEditRetangle;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction;

constructor TRickUIBuilderEditRetanglePosition.Create(const AParent: IRickUIBuilderEditRetangle; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditRetanglePosition.New(const AParent: IRickUIBuilderEditRetangle; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditRetanglePosition;
begin
  Result := TRickUIBuilderEditRetanglePosition.Create(AParent, AContext);
end;

function TRickUIBuilderEditRetanglePosition.Left(AValue: Single): IRickUIBuilderEditRetanglePosition;
begin
  FContext.Settings.Rectangle.Left := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditRetanglePosition.Top(AValue: Single): IRickUIBuilderEditRetanglePosition;
begin
  FContext.Settings.Rectangle.Top := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditRetanglePosition.ToBack: IRickUIBuilderEditRetangle;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

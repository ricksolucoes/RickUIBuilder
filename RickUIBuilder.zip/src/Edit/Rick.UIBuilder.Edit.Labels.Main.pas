﻿unit Rick.UIBuilder.Edit.Labels.Main;

interface

uses
  System.UITypes,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces;

type
  TRickUIBuilderEditLabelMain = class(TInterfacedObject, IRickUIBuilderEditLabelMain)
  strict private
    [weak] FParent: IRickUIBuilderEditLabel;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
    FText: IRickUIBuilderEditLabelMainText;
  protected
    constructor Create(const AParent: IRickUIBuilderEditLabel; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditLabel; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLabelMain; static;
    function Text: IRickUIBuilderEditLabelMainText;
    function ToBack: IRickUIBuilderEditLabel;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Labels.Main.Text;

constructor TRickUIBuilderEditLabelMain.Create(const AParent: IRickUIBuilderEditLabel; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditLabelMain.New(const AParent: IRickUIBuilderEditLabel; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLabelMain;
begin
  Result := TRickUIBuilderEditLabelMain.Create(AParent, AContext);
end;

function TRickUIBuilderEditLabelMain.Text: IRickUIBuilderEditLabelMainText;
begin
  if not Assigned(FText) then
    FText := TRickUIBuilderEditLabelMainText.New(Self, FContext);
  Result := FText;
end;

function TRickUIBuilderEditLabelMain.ToBack: IRickUIBuilderEditLabel;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

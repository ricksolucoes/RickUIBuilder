﻿unit Rick.UIBuilder.Edit.Labels.Counter;

interface

uses
  System.UITypes,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces;

type
  TRickUIBuilderEditLabelCounter = class(TInterfacedObject, IRickUIBuilderEditLabelCounter)
  strict private
    [weak] FParent: IRickUIBuilderEditLabel;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
  protected
    constructor Create(const AParent: IRickUIBuilderEditLabel; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditLabel; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLabelCounter; static;
    function Enabled(AValue: Boolean): IRickUIBuilderEditLabelCounter; overload;
    function Enabled: IRickUIBuilderEditLabelCounter; overload;
    function ToBack: IRickUIBuilderEditLabel;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction;

constructor TRickUIBuilderEditLabelCounter.Create(const AParent: IRickUIBuilderEditLabel; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditLabelCounter.New(const AParent: IRickUIBuilderEditLabel; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLabelCounter;
begin
  Result := TRickUIBuilderEditLabelCounter.Create(AParent, AContext);
end;

function TRickUIBuilderEditLabelCounter.Enabled(AValue: Boolean): IRickUIBuilderEditLabelCounter;
begin
  FContext.Settings.Labels.CounterEnabled := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditLabelCounter.Enabled: IRickUIBuilderEditLabelCounter;
begin
  Result := Enabled(True);
end;

function TRickUIBuilderEditLabelCounter.ToBack: IRickUIBuilderEditLabel;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

﻿unit Rick.UIBuilder.Edit.Labels.Error.Text.Font;

interface

uses
  System.UITypes,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces;

type
  TRickUIBuilderEditLabelErrorTextFont = class(TInterfacedObject, IRickUIBuilderEditLabelErrorTextFont)
  strict private
    [weak] FParent: IRickUIBuilderEditLabelErrorText;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
  protected
    constructor Create(const AParent: IRickUIBuilderEditLabelErrorText; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditLabelErrorText; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLabelErrorTextFont; static;
    function Family(const AValue: string): IRickUIBuilderEditLabelErrorTextFont;
    function Size(AValue: Single): IRickUIBuilderEditLabelErrorTextFont;
    function Styles(AValue: TFontStyles): IRickUIBuilderEditLabelErrorTextFont;
    function ToBack: IRickUIBuilderEditLabelErrorText;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction;

constructor TRickUIBuilderEditLabelErrorTextFont.Create(const AParent: IRickUIBuilderEditLabelErrorText; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditLabelErrorTextFont.New(const AParent: IRickUIBuilderEditLabelErrorText; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLabelErrorTextFont;
begin
  Result := TRickUIBuilderEditLabelErrorTextFont.Create(AParent, AContext);
end;

function TRickUIBuilderEditLabelErrorTextFont.Family(const AValue: string): IRickUIBuilderEditLabelErrorTextFont;
begin
  FContext.Settings.Labels.ErrorFontFamily := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditLabelErrorTextFont.Size(AValue: Single): IRickUIBuilderEditLabelErrorTextFont;
begin
  FContext.Settings.Labels.ErrorFontSize := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditLabelErrorTextFont.Styles(AValue: TFontStyles): IRickUIBuilderEditLabelErrorTextFont;
begin
  FContext.Settings.Labels.ErrorFontStyles := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditLabelErrorTextFont.ToBack: IRickUIBuilderEditLabelErrorText;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

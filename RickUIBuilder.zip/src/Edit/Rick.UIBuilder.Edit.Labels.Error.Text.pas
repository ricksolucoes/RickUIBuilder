﻿unit Rick.UIBuilder.Edit.Labels.Error.Text;

interface

uses
  System.UITypes,
  Rick.UIBuilder.Edit.Context,
  Rick.UIBuilder.Edit.Interfaces;

type
  TRickUIBuilderEditLabelErrorText = class(TInterfacedObject, IRickUIBuilderEditLabelErrorText)
  strict private
    [weak] FParent: IRickUIBuilderEditLabelError;
    FContextRef: IInterface;
    FContext: TRickUIBuilderEditContext;
    FFont: IRickUIBuilderEditLabelErrorTextFont;
  protected
    constructor Create(const AParent: IRickUIBuilderEditLabelError; AContext: TRickUIBuilderEditContext);
  public
    class function New(const AParent: IRickUIBuilderEditLabelError; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLabelErrorText; static;
    function Value(AValue: string): IRickUIBuilderEditLabelErrorText;
    function Color(AValue: TAlphaColor): IRickUIBuilderEditLabelErrorText;
    function Spacing(AValue: Single): IRickUIBuilderEditLabelErrorText;
    function Font: IRickUIBuilderEditLabelErrorTextFont;
    function ToBack: IRickUIBuilderEditLabelError;
  end;

implementation

uses
  System.SysUtils,
  Rick.UIBuilder.Edit.Interaction,
  Rick.UIBuilder.Edit.Labels.Error.Text.Font;

constructor TRickUIBuilderEditLabelErrorText.Create(const AParent: IRickUIBuilderEditLabelError; AContext: TRickUIBuilderEditContext);
begin
  inherited Create;
  FParent := AParent;
  FContext := AContext;
  FContextRef := AContext as IInterface;
end;

class function TRickUIBuilderEditLabelErrorText.New(const AParent: IRickUIBuilderEditLabelError; AContext: TRickUIBuilderEditContext): IRickUIBuilderEditLabelErrorText;
begin
  Result := TRickUIBuilderEditLabelErrorText.Create(AParent, AContext);
end;

function TRickUIBuilderEditLabelErrorText.Value(AValue: string): IRickUIBuilderEditLabelErrorText;
begin
  FContext.Settings.Labels.ErrorText := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditLabelErrorText.Color(AValue: TAlphaColor): IRickUIBuilderEditLabelErrorText;
begin
  FContext.Settings.Labels.ErrorTextColor := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditLabelErrorText.Spacing(AValue: Single): IRickUIBuilderEditLabelErrorText;
begin
  FContext.Settings.Labels.ErrorSpacing := AValue;
  if FContext.Interaction is TRickUIBuilderEditInteraction then
    TRickUIBuilderEditInteraction(FContext.Interaction).SyncSettings(FContext.Settings);
  Result := Self;
end;

function TRickUIBuilderEditLabelErrorText.Font: IRickUIBuilderEditLabelErrorTextFont;
begin
  if not Assigned(FFont) then
    FFont := TRickUIBuilderEditLabelErrorTextFont.New(Self, FContext);
  Result := FFont;
end;

function TRickUIBuilderEditLabelErrorText.ToBack: IRickUIBuilderEditLabelError;
begin
  if not Assigned(FParent) then
    raise Exception.Create('O Parent da interface não foi informado para retornar.');
  Result := FParent;
end;

end.

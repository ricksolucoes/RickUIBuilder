﻿unit Rick.UIBuilder.Tests.Edit;
{$SCOPEDENUMS ON}

interface

uses
  DUnitX.TestFramework,
  FMX.Forms,
  Rick.UIBuilder.Types,
  Rick.UIBuilder.Interfaces;

type
  [TestFixture]
  TRickUIBuilderEditInputTests = class
  public
    [Test] procedure CPF_DeveAplicarMascaraDuranteFormatacao;
    [Test] procedure CPF_DeveAplicarMascaraProgressivamente;
    [Test] procedure CPF_DeveRejeitarLetrasDuranteDigitacao;
    [Test] procedure CPF_DeveLimitarOnzeDigitos;
    [Test] procedure CPF_PasteSemMascara_DeveSerRejeitado;
    [Test] procedure CPF_PasteComMascara_DeveSerAceito;
    [Test] procedure CNPJ_DeveAceitarBaseAlfanumerica;
    [Test] procedure CNPJ_DoisUltimosCaracteresDevemSerNumericos;
    [Test] procedure CEP_DeveAplicarMascara;
    [Test] procedure Telefone_DeveAdicionarDDDQuandoNecessario;
    [Test] procedure Celular_DeveAdicionarDDDQuandoNecessario;
    [Test] procedure Inteiro_NegativoDeveRespeitarConfiguracao;
    [Test] procedure Float_DeveRespeitarCasasDecimais;
    [Test] procedure Email_DeveConverterParaLowercase;
    [Test] procedure Email_DeveRejeitarCaracteresForaDoAddrSpec;
    [Test] procedure Email_DeveAceitarAtextConvencionadoNoLocalPart;
    [Test] procedure Email_DominioDeveRejeitarUnderscore;
    [Test] procedure Email_DeveRejeitarSegundoArroba;
    [Test] procedure Email_IncompletoDeveSerInvalido;
    [Test] procedure Email_CompletoDeveSerValido;
    [Test] procedure Email_DotAtomInvalidoDeveSerRejeitado;
    [Test] procedure Email_QuotedLocalPartDeveSerRejeitado;
    [Test] procedure Email_EAIDeveAceitarUTF8;
    [Test] procedure URL_SchemeEHostDevemSerLowercase;
    [Test] procedure URL_EntireValueDeveSerLowercase;
    [Test] procedure URL_DeveAceitarHostsWebValidos;
    [Test] procedure URL_DeveAceitarLocalhost;
    [Test] procedure URL_DeveAceitarIPv4EIPv6;
    [Test] procedure URL_DeveValidarPorta;
    [Test] procedure URL_DeveRejeitarHostsInvalidos;
    [Test] procedure URL_DeveRejeitarSchemeInvalido;
    [Test] procedure Required_DeveConsiderarTrimComoVazio;
    [Test] procedure Opcional_DevePermitirVazio;
    [Test] procedure TextoComPontuacao_DeveAceitarSimbolosAprovados;
    [Test] procedure TextoSemAcentos_DeveRejeitarAcentos;
  end;

  [TestFixture]
  [Category('Integration')]
  TRickUIBuilderEditIntegrationTests = class
  private
    FHostForm: TForm;
  public
    [Setup] procedure Setup;
    [TearDown] procedure TearDown;
    [Test] procedure Facade_DeveCriarEditSingleLine;
    [Test] procedure State_DeveSerCacheadoERetornarParent;
    [Test] procedure State_MutadoresDevemRetornarMesmoState;
    [Test] procedure State_TextDeveSerAplicadoNoBuild;
    [Test] procedure State_InvalidBooleanDeveSerAplicadoNoBuild;
    [Test] procedure State_InvalidMensagemDeveSerAplicadoNoBuild;
    [Test] procedure State_InvalidCompletoDeveRespeitarBoolean;
    [Test] procedure State_RequirementMetDeveSerAplicadoNoBuild;
    [Test] procedure State_WeakParentNaoDeveCriarCiclo;
    [Test] procedure Handle_DeveAlterarTextoELimpar;
    [Test] procedure Edit_DeveFiltrarDuranteChangeTracking;
    [Test] procedure Edit_ReadOnlyDeveBloquearEdicao;
    [Test] procedure Edit_DefaultDevePreservarAparenciaAtual;
    [Test] procedure Edit_MensagemDeveForcarAlturaMinima;
    [Test] procedure Edit_SemIconeVisivelDeveUsarTodaLarguraUtil;
    [Test] procedure Edit_AoSairDeveReposicionarVisualizacaoNoInicio;
  end;

implementation

uses
  System.SysUtils,
  System.UITypes,

  FMX.Objects,
  FMX.StdCtrls,
  FMX.Types,

  Rick.UIBuilder,
  Rick.UIBuilder.Edit.Input;

function FindLabelByText(AContainer: TRectangle; const AText: string): TLabel;
var
  I: Integer;
  LChild: TFmxObject;
begin
  Result := nil;
  for I := 0 to AContainer.ChildrenCount - 1 do
  begin
    LChild := AContainer.Children[I];
    if (LChild is TLabel) and (TLabel(LChild).Text = AText) then
      Exit(TLabel(LChild));
  end;
end;

function FindVisiblePath(AContainer: TRectangle): TPath;
var
  I: Integer;
  LChild: TFmxObject;
begin
  Result := nil;
  for I := 0 to AContainer.ChildrenCount - 1 do
  begin
    LChild := AContainer.Children[I];
    if (LChild is TPath) and TPath(LChild).Visible then
      Exit(TPath(LChild));
  end;
end;

function BuildRequirementState(AHost: TFmxObject; AValue: Boolean): IRickUIBuilderEditHandle;
begin
  Result := TRickUIBuilder.Edit
    .RequirementIndicator(True)
    .RequirementMetPath('M 0 0 L 10 0')
    .RequirementNotMetPath('M 0 0 L 0 10')
    .State
      .RequirementMet(AValue)
    .ToBack
    .Build(AHost);
end;

function Config(APreset: TRickUIBuilderEditPreset): TRickUIBuilderEditConfig;
begin
  Result := TRickUIBuilderEditConfig.Default;
  Result.Preset := APreset;
end;

procedure TRickUIBuilderEditInputTests.CPF_DeveAplicarMascaraDuranteFormatacao;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.CPF);
  Assert.AreEqual('123.456.789-01',
    TRickUIBuilderEditInput.FormatTypedValue('12345678901', LConfig));
end;

procedure TRickUIBuilderEditInputTests.CPF_DeveAplicarMascaraProgressivamente;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.CPF);
  Assert.AreEqual('123.4',
    TRickUIBuilderEditInput.FormatTypedValue('1234', LConfig));
end;

procedure TRickUIBuilderEditInputTests.CPF_DeveRejeitarLetrasDuranteDigitacao;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.CPF);
  Assert.IsFalse(TRickUIBuilderEditInput.IsTypedValueAllowed('12A', LConfig));
end;

procedure TRickUIBuilderEditInputTests.CPF_DeveLimitarOnzeDigitos;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.CPF);
  Assert.AreEqual('123.456.789-01',
    TRickUIBuilderEditInput.FormatTypedValue('1234567890123', LConfig));
end;

procedure TRickUIBuilderEditInputTests.CPF_PasteSemMascara_DeveSerRejeitado;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.CPF);
  Assert.IsFalse(TRickUIBuilderEditInput.IsPasteAllowed('12345678901', LConfig));
end;

procedure TRickUIBuilderEditInputTests.CPF_PasteComMascara_DeveSerAceito;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.CPF);
  Assert.IsTrue(TRickUIBuilderEditInput.IsPasteAllowed('123.456.789-01', LConfig));
end;

procedure TRickUIBuilderEditInputTests.CNPJ_DeveAceitarBaseAlfanumerica;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.CNPJ);
  Assert.AreEqual('00.000.000/E08G-12',
    TRickUIBuilderEditInput.FormatTypedValue('00000000E08G12', LConfig));
end;

procedure TRickUIBuilderEditInputTests.CNPJ_DoisUltimosCaracteresDevemSerNumericos;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.CNPJ);
  Assert.IsFalse(TRickUIBuilderEditInput.IsPasteAllowed('00.000.000/E08G-AB', LConfig));
end;

procedure TRickUIBuilderEditInputTests.CEP_DeveAplicarMascara;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.CEP);
  Assert.AreEqual('12345-678', TRickUIBuilderEditInput.FormatTypedValue('12345678', LConfig));
end;

procedure TRickUIBuilderEditInputTests.Telefone_DeveAdicionarDDDQuandoNecessario;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.Phone);
  Assert.AreEqual('(21) 2345-6789', TRickUIBuilderEditInput.FormatTypedValue('2123456789', LConfig));
end;

procedure TRickUIBuilderEditInputTests.Celular_DeveAdicionarDDDQuandoNecessario;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.Mobile);
  Assert.AreEqual('(21) 9 1234-5678', TRickUIBuilderEditInput.FormatTypedValue('21912345678', LConfig));
end;

procedure TRickUIBuilderEditInputTests.Inteiro_NegativoDeveRespeitarConfiguracao;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.IntegerNumber);
  Assert.IsFalse(TRickUIBuilderEditInput.IsValueAllowed('-10', LConfig));
  LConfig.AllowNegative := True;
  Assert.IsTrue(TRickUIBuilderEditInput.IsValueAllowed('-10', LConfig));
end;

procedure TRickUIBuilderEditInputTests.Float_DeveRespeitarCasasDecimais;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.FloatNumber);
  LConfig.NumberFormatMode := TRickUIBuilderEditNumberFormatMode.Custom;
  LConfig.DecimalSeparator := ',';
  LConfig.DecimalPlaces := 2;
  Assert.IsTrue(TRickUIBuilderEditInput.IsValueAllowed('10,25', LConfig));
  Assert.IsFalse(TRickUIBuilderEditInput.IsValueAllowed('10,256', LConfig));
end;

procedure TRickUIBuilderEditInputTests.Email_DeveConverterParaLowercase;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.Email);
  Assert.AreEqual('nome@exemplo.com',
    TRickUIBuilderEditInput.FormatTypedValue('Nome@Exemplo.COM', LConfig));
end;

procedure TRickUIBuilderEditInputTests.Email_DeveRejeitarCaracteresForaDoAddrSpec;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.Email);
  Assert.IsFalse(TRickUIBuilderEditInput.IsTypedValueAllowed(
    '***))))((((%cccc', LConfig));
  Assert.IsFalse(TRickUIBuilderEditInput.IsTypedValueAllowed(
    '*&&&&&&&$%#*!!!!!{{', LConfig));
  Assert.IsFalse(TRickUIBuilderEditInput.IsTypedValueAllowed(
    'nome&sobrenome@example.com', LConfig));
  Assert.IsFalse(TRickUIBuilderEditInput.IsTypedValueAllowed(
    'nome%tag@example.com', LConfig));
end;

procedure TRickUIBuilderEditInputTests.Email_DeveAceitarAtextConvencionadoNoLocalPart;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.Email);
  Assert.IsTrue(TRickUIBuilderEditInput.IsTypedValueAllowed(
    'nome.sobrenome+tag@example.com', LConfig));
  Assert.IsTrue(TRickUIBuilderEditInput.IsTypedValueAllowed(
    'nome_sobrenome@example.com', LConfig));
  Assert.IsTrue(TRickUIBuilderEditInput.IsTypedValueAllowed(
    'nome-sobrenome@example.com', LConfig));
end;

procedure TRickUIBuilderEditInputTests.Email_DominioDeveRejeitarUnderscore;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.Email);
  Assert.IsFalse(TRickUIBuilderEditInput.IsTypedValueAllowed(
    'nome@dominio_invalido.com', LConfig));
end;

procedure TRickUIBuilderEditInputTests.Email_DeveRejeitarSegundoArroba;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.Email);
  Assert.IsFalse(TRickUIBuilderEditInput.IsTypedValueAllowed(
    'nome@@example.com', LConfig));
end;

procedure TRickUIBuilderEditInputTests.Email_IncompletoDeveSerInvalido;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.Email);
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue('erwrwerw', LConfig));
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue('nome@', LConfig));
end;

procedure TRickUIBuilderEditInputTests.Email_CompletoDeveSerValido;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.Email);
  Assert.IsTrue(TRickUIBuilderEditInput.IsCompleteValue(
    'nome.sobrenome+tag@example.com', LConfig));
end;

procedure TRickUIBuilderEditInputTests.Email_DotAtomInvalidoDeveSerRejeitado;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.Email);
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue(
    '.nome@example.com', LConfig));
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue(
    'nome..sobrenome@example.com', LConfig));
end;

procedure TRickUIBuilderEditInputTests.Email_QuotedLocalPartDeveSerRejeitado;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.Email);
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue(
    '"Fred Bloggs"@example.com', LConfig));
end;

procedure TRickUIBuilderEditInputTests.Email_EAIDeveAceitarUTF8;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.Email);
  Assert.IsTrue(TRickUIBuilderEditInput.IsCompleteValue(
    'usuário@exemplo.com', LConfig));
end;

procedure TRickUIBuilderEditInputTests.URL_SchemeEHostDevemSerLowercase;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.URL);
  Assert.AreEqual('https://example.com/Path?Token=ABC',
    TRickUIBuilderEditInput.FormatTypedValue('HTTPS://Example.COM/Path?Token=ABC', LConfig));
end;

procedure TRickUIBuilderEditInputTests.URL_EntireValueDeveSerLowercase;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.URL);
  LConfig.UrlCaseMode := TRickUIBuilderEditUrlCaseMode.EntireValue;
  Assert.AreEqual('https://example.com/path?token=abc',
    TRickUIBuilderEditInput.FormatTypedValue('HTTPS://Example.COM/Path?Token=ABC', LConfig));
end;

procedure TRickUIBuilderEditInputTests.URL_DeveAceitarHostsWebValidos;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.URL);
  Assert.IsTrue(TRickUIBuilderEditInput.IsCompleteValue('example.com', LConfig));
  Assert.IsTrue(TRickUIBuilderEditInput.IsCompleteValue('example.ai', LConfig));
  Assert.IsTrue(TRickUIBuilderEditInput.IsCompleteValue('a.b', LConfig));
  Assert.IsTrue(TRickUIBuilderEditInput.IsCompleteValue('empresa.com.br/path?x=1#top', LConfig));
  Assert.IsTrue(TRickUIBuilderEditInput.IsCompleteValue('https://example.ai/Path?Token=ABC', LConfig));
end;

procedure TRickUIBuilderEditInputTests.URL_DeveAceitarLocalhost;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.URL);
  Assert.IsTrue(TRickUIBuilderEditInput.IsCompleteValue('localhost', LConfig));
  Assert.IsTrue(TRickUIBuilderEditInput.IsCompleteValue('localhost:8080/api', LConfig));
  Assert.IsTrue(TRickUIBuilderEditInput.IsCompleteValue('http://localhost', LConfig));
end;

procedure TRickUIBuilderEditInputTests.URL_DeveAceitarIPv4EIPv6;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.URL);
  Assert.IsTrue(TRickUIBuilderEditInput.IsCompleteValue('127.0.0.1/test', LConfig));
  Assert.IsTrue(TRickUIBuilderEditInput.IsCompleteValue('[2001:db8::1]/api', LConfig));
  Assert.IsTrue(TRickUIBuilderEditInput.IsCompleteValue('http://[::1]:8080/api', LConfig));
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue('256.1.1.1', LConfig));
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue('[1::1::1]', LConfig));
end;

procedure TRickUIBuilderEditInputTests.URL_DeveValidarPorta;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.URL);
  Assert.IsTrue(TRickUIBuilderEditInput.IsCompleteValue('example.com:65535', LConfig));
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue('example.com:65536', LConfig));
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue('example.com:abc', LConfig));
end;

procedure TRickUIBuilderEditInputTests.URL_DeveRejeitarHostsInvalidos;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.URL);
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue('-teste.com', LConfig));
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue('teste-.com', LConfig));
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue('teste..com', LConfig));
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue('exa_mple.com', LConfig));
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue('/abc', LConfig));
end;

procedure TRickUIBuilderEditInputTests.URL_DeveRejeitarSchemeInvalido;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.URL);
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue('ftp://example.com', LConfig));
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue('https://', LConfig));
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue('https:///example.com', LConfig));
end;

procedure TRickUIBuilderEditInputTests.Required_DeveConsiderarTrimComoVazio;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.URL);
  LConfig.Required := True;
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue(EmptyStr, LConfig));
  Assert.IsFalse(TRickUIBuilderEditInput.IsCompleteValue('   ', LConfig));
end;

procedure TRickUIBuilderEditInputTests.Opcional_DevePermitirVazio;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.URL);
  Assert.IsTrue(TRickUIBuilderEditInput.IsCompleteValue(EmptyStr, LConfig));
  Assert.IsTrue(TRickUIBuilderEditInput.IsCompleteValue('   ', LConfig));
end;

procedure TRickUIBuilderEditInputTests.TextoComPontuacao_DeveAceitarSimbolosAprovados;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.TextPunctuationWithAccents);
  Assert.IsTrue(TRickUIBuilderEditInput.IsValueAllowed('Olá — teste: % #ok', LConfig));
end;

procedure TRickUIBuilderEditInputTests.TextoSemAcentos_DeveRejeitarAcentos;
var LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := Config(TRickUIBuilderEditPreset.TextNoAccents);
  Assert.IsFalse(TRickUIBuilderEditInput.IsValueAllowed('João', LConfig));
end;

procedure TRickUIBuilderEditIntegrationTests.Setup;
begin
  FHostForm := TForm.CreateNew(nil);
end;

procedure TRickUIBuilderEditIntegrationTests.TearDown;
begin
  FHostForm.Free;
end;

procedure TRickUIBuilderEditIntegrationTests.Facade_DeveCriarEditSingleLine;
var LHandle: IRickUIBuilderEditHandle;
begin
  LHandle := TRickUIBuilder.Edit.LabelText('Nome').Build(FHostForm);
  Assert.IsNotNull(LHandle);
  Assert.IsNotNull(LHandle.EditControl);
end;

procedure TRickUIBuilderEditIntegrationTests.State_DeveSerCacheadoERetornarParent;
var
  LEdit, LBack: IRickUIBuilderEdit;
  LState1, LState2: IRickUIBuilderEditState;
begin
  LEdit := TRickUIBuilder.Edit;
  LState1 := LEdit.State;
  LState2 := LEdit.State;
  LBack := LState1.ToBack;

  Assert.IsTrue(LState1 = LState2);
  Assert.IsTrue(LEdit = LBack);
end;

procedure TRickUIBuilderEditIntegrationTests.State_MutadoresDevemRetornarMesmoState;
var
  LEdit: IRickUIBuilderEdit;
  LState, LResult: IRickUIBuilderEditState;
begin
  LEdit := TRickUIBuilder.Edit;
  LState := LEdit.State;
  LResult := LState.Text('Texto').Invalid(True).RequirementMet(True);

  Assert.IsTrue(LState = LResult);
end;

procedure TRickUIBuilderEditIntegrationTests.State_TextDeveSerAplicadoNoBuild;
var
  LHandle: IRickUIBuilderEditHandle;
begin
  LHandle := TRickUIBuilder.Edit
    .State
      .Text('Texto configurado no State')
    .ToBack
    .Build(FHostForm);

  Assert.AreEqual('Texto configurado no State', LHandle.Text);
end;

procedure TRickUIBuilderEditIntegrationTests.State_InvalidBooleanDeveSerAplicadoNoBuild;
var
  LConfig: TRickUIBuilderEditConfig;
  LHandle: IRickUIBuilderEditHandle;
begin
  LConfig := TRickUIBuilderEditConfig.Default;
  LHandle := TRickUIBuilder.Edit
    .State
      .Invalid(True)
    .ToBack
    .Build(FHostForm);

  Assert.AreEqual<TAlphaColor>(LConfig.InvalidBackgroundColor, LHandle.Container.Fill.Color);
end;

procedure TRickUIBuilderEditIntegrationTests.State_InvalidMensagemDeveSerAplicadoNoBuild;
var
  LHandle: IRickUIBuilderEditHandle;
  LLabel: TLabel;
begin
  LHandle := TRickUIBuilder.Edit
    .InvalidFeedback(TRickUIBuilderEditInvalidFeedback.AlertOnly)
    .State
      .Invalid('Erro configurado no State')
    .ToBack
    .Build(FHostForm);
  LLabel := FindLabelByText(LHandle.Container, 'Erro configurado no State');

  Assert.IsNotNull(LLabel);
  Assert.IsTrue(LLabel.Visible);
end;

procedure TRickUIBuilderEditIntegrationTests.State_InvalidCompletoDeveRespeitarBoolean;
var
  LConfig: TRickUIBuilderEditConfig;
  LHandle: IRickUIBuilderEditHandle;
  LLabel: TLabel;
begin
  LConfig := TRickUIBuilderEditConfig.Default;
  LHandle := TRickUIBuilder.Edit
    .InvalidFeedback(TRickUIBuilderEditInvalidFeedback.AlertOnly)
    .State
      .Invalid(False, 'Mensagem inativa')
    .ToBack
    .Build(FHostForm);
  LLabel := FindLabelByText(LHandle.Container, 'Mensagem inativa');

  Assert.AreEqual<TAlphaColor>(LConfig.BackgroundColor, LHandle.Container.Fill.Color);
  Assert.IsNotNull(LLabel);
  Assert.IsFalse(LLabel.Visible);
end;

procedure TRickUIBuilderEditIntegrationTests.State_RequirementMetDeveSerAplicadoNoBuild;
var
  LMetHandle, LNotMetHandle: IRickUIBuilderEditHandle;
  LMetPath, LNotMetPath: TPath;
begin
  LMetHandle := BuildRequirementState(FHostForm, True);
  LNotMetHandle := BuildRequirementState(FHostForm, False);
  LMetPath := FindVisiblePath(LMetHandle.Container);
  LNotMetPath := FindVisiblePath(LNotMetHandle.Container);

  Assert.IsNotNull(LMetPath);
  Assert.IsNotNull(LNotMetPath);
  Assert.AreNotEqual(LMetPath.Data.Data, LNotMetPath.Data.Data);
end;

procedure TRickUIBuilderEditIntegrationTests.State_WeakParentNaoDeveCriarCiclo;
var
  LEdit: IRickUIBuilderEdit;
  LMessage: string;
  LState: IRickUIBuilderEditState;
begin
  LEdit := TRickUIBuilder.Edit;
  LState := LEdit.State;
  LEdit := nil;
  LMessage := EmptyStr;
  try
    LState.ToBack;
  except
    on E: Exception do
      LMessage := E.Message;
  end;

  Assert.AreEqual('O Parent da interface não foi informado para retornar.', LMessage);
end;

procedure TRickUIBuilderEditIntegrationTests.Handle_DeveAlterarTextoELimpar;
var LHandle: IRickUIBuilderEditHandle;
begin
  LHandle := TRickUIBuilder.Edit.Build(FHostForm);
  LHandle.Text('abc');
  Assert.AreEqual('abc', LHandle.Text);
  LHandle.Clear;
  Assert.AreEqual('', LHandle.Text);
end;

procedure TRickUIBuilderEditIntegrationTests.Edit_DeveFiltrarDuranteChangeTracking;
var LHandle: IRickUIBuilderEditHandle;
begin
  LHandle := TRickUIBuilder.Edit
    .Preset(TRickUIBuilderEditPreset.CPF)
    .Build(FHostForm);
  Assert.IsTrue(Assigned(LHandle.EditControl.OnChangeTracking));
  LHandle.EditControl.Text := '1234';
  Assert.AreEqual('123.4', LHandle.Text);
  LHandle.EditControl.Text := LHandle.Text + 'A';
  Assert.AreEqual('123.4', LHandle.Text);
end;

procedure TRickUIBuilderEditIntegrationTests.Edit_ReadOnlyDeveBloquearEdicao;
var
  LHandle: IRickUIBuilderEditHandle;
begin
  LHandle := TRickUIBuilder.Edit.Text('Somente leitura').ReadOnly.Build(FHostForm);
  Assert.IsTrue(LHandle.EditControl.ReadOnly);
  Assert.AreEqual('Somente leitura', LHandle.Text);
end;

procedure TRickUIBuilderEditIntegrationTests.Edit_DefaultDevePreservarAparenciaAtual;
var
  LConfig: TRickUIBuilderEditConfig;
begin
  LConfig := TRickUIBuilderEditConfig.Default;
  Assert.AreEqual(Integer(TRickUIBuilderEditAppearance.Outlined),
    Integer(LConfig.Appearance));
  Assert.IsFalse(LConfig.ReadOnly);
  Assert.IsFalse(LConfig.Required);
  Assert.AreEqual<Single>(12.0, LConfig.LabelFontSize);
  Assert.AreEqual<Single>(11.0, LConfig.ErrorFontSize);
end;


procedure TRickUIBuilderEditIntegrationTests.Edit_MensagemDeveForcarAlturaMinima;
var
  LHandle: IRickUIBuilderEditHandle;
begin
  LHandle := TRickUIBuilder.Edit
    .LabelText('Título').InvalidMessage('Mensagem').Size(300, 20)
    .Build(FHostForm);
  Assert.IsTrue(LHandle.Container.Height > 20);
end;

procedure TRickUIBuilderEditIntegrationTests.Edit_SemIconeVisivelDeveUsarTodaLarguraUtil;
var
  LHandle: IRickUIBuilderEditHandle;
begin
  LHandle := TRickUIBuilder.Edit.ClearButton.Size(300, 56).Build(FHostForm);
  Assert.AreEqual<Single>(284, LHandle.EditControl.Width);
  LHandle.Text('conteúdo');
  Assert.AreEqual<Single>(252, LHandle.EditControl.Width);
  LHandle.Clear;
  Assert.AreEqual<Single>(284, LHandle.EditControl.Width);
end;

procedure TRickUIBuilderEditIntegrationTests.Edit_AoSairDeveReposicionarVisualizacaoNoInicio;
var
  LHandle: IRickUIBuilderEditHandle;
begin
  LHandle := TRickUIBuilder.Edit
    .Text('https://chatgpt.com/g/g-p-6ab4204f8ae48191bc9bf0b66dbefdd4')
    .Build(FHostForm);
  LHandle.EditControl.CaretPosition := Length(LHandle.Text);
  Assert.IsTrue(Assigned(LHandle.EditControl.OnExit));
  LHandle.EditControl.OnExit(LHandle.EditControl);
  Assert.AreEqual(0, LHandle.EditControl.CaretPosition);
end;

initialization
  TDUnitX.RegisterTestFixture(TRickUIBuilderEditInputTests);
  TDUnitX.RegisterTestFixture(TRickUIBuilderEditIntegrationTests);

end.
